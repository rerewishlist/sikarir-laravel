    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('assets-guest/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-guest/vendor/php-email-form/validate.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-guest/vendor/aos/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-guest/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets-guest/vendor/swiper/swiper-bundle.min.js')); ?>"></script>

    <!-- Main JS File -->
    <script src="<?php echo e(asset('assets-guest/js/main.js')); ?>"></script>


<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/layouts/partial-guest/script.blade.php ENDPATH**/ ?>