<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
        &copy; 2024 <strong><span>NAMA WEB</span></strong>. Ver. 2024.1.1
    </div>
</footer><!-- End Footer -->
<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/layouts/partial/footer.blade.php ENDPATH**/ ?>