<section class="section">
    <div class="row mb-3">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Selamat Datang</h5>
                    <h3 class="card-body"><?php echo e($currentUser->nama); ?></h3>
                </div>
            </div>
        </div>

        <section class="section">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="card-title">Berita Terbaru</h5>
                                <!-- Form Pencarian -->
                                <form method="GET" action="<?php echo e(url('/siswa/dashboard')); ?>" class="d-flex search-form">
                                    <input style="margin-right: 10px;" type="text" name="search_berita" class="form-control"
                                        placeholder="Cari judul berita..." value="<?php echo e(request('search_berita')); ?>">

                                    <!-- Dropdown untuk memilih kategori -->
                                    <select name="filter_kategori" class="form-control" style="margin-right: 10px;">
                                        <option value="">-- Pilih Kategori --</option>
                                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kategori->id); ?>" <?php echo e(request('filter_kategori') == $kategori->id ? 'selected' : ''); ?>>
                                                <?php echo e($kategori->nama); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit" class="btn btn-primary">Cari</button>
                                </form>
                                <!-- End Form Pencarian -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php if($allBerita->count() > 0): ?>
            <?php $__currentLoopData = $allBerita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-12">
                    <div class="card">
                        <?php
                            $randomImages = [
                                'assets/img/berita1.jpeg',
                                'assets/img/berita2.jpeg',
                                'assets/img/berita3.jpeg',
                                'assets/img/berita4.jpeg',
                                'assets/img/berita5.jpeg',
                            ];
                            $randomImage = $randomImages[array_rand($randomImages)];
                        ?>
                        <?php if($item->gambar): ?>
                            <img src="<?php echo e(asset('storage/berita/' . $item->gambar)); ?>" alt="foto" class="card-img-top"
                                style="height: 300px; object-fit: cover;">
                        <?php else: ?>
                            <img src="<?php echo e(asset($randomImage)); ?>" alt="foto" class="card-img-top" style="height: 300px; object-fit: cover;">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item->judul); ?></h5>
                            <p class="card-text"><?php echo \Illuminate\Support\Str::limit(strip_tags($item->content), 400, '...'); ?></p>
                            <a href="<?php echo e(route('user.berita.detail', $item->id)); ?>" class="btn btn-primary">Selengkapnya...</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <p class="card-text mt-4">Tidak ada berita terbaru</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>

    <!-- Paginate -->
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <!-- Previous Page Link -->
            <?php if($allBerita->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link">Previous</span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($allBerita->previousPageUrl()); ?>">Previous</a>
                </li>
            <?php endif; ?>

            <!-- Pagination Elements -->
            <?php for($i = 1; $i <= $allBerita->lastPage(); $i++): ?>
                <li class="page-item <?php echo e($i == $allBerita->currentPage() ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($allBerita->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>

            <!-- Next Page Link -->
            <?php if($allBerita->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($allBerita->nextPageUrl()); ?>">Next</a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">Next</span></li>
            <?php endif; ?>
        </ul>
    </nav>
    <!-- End Paginate -->
</section>

<script>
    window.addEventListener('load', function() {
        // Menghapus parameter pencarian dari URL saat halaman di-refresh
        var url = new URL(window.location.href);
        url.searchParams.delete('search_berita');
        url.searchParams.delete('filter_kategori');
        window.history.replaceState({}, document.title, url.toString());
    });
</script>
<?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/siswa/dashboard-siswa.blade.php ENDPATH**/ ?>