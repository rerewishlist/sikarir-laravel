<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title">Table Data Forum Diskusi</h5>
                        <!-- Form Pencarian -->
                        <form method="GET" action="<?php echo e(url('/siswa/forumdiskusi')); ?>" class="d-flex search-form">
                            <input style="margin-right: 10px;" type="text" name="search_forum" class="form-control" placeholder="Cari data foru..."
                                value="<?php echo e(request('search_forum')); ?>">
                            <button type="submit" class="btn btn-primary">Cari</button>
                        </form>
                        <!-- End Form Pencarian -->
                    </div>
                    <!-- Button Modal Tambah Forum-->
                    <a href="<?php echo e(route('user.dataforum.create')); ?>" class="btn btn-success mb-3">
                        <i class="bi bi-plus me-1"></i> Buat Forum
                    </a>
                    <!-- End button Modal Tambah Forum -->
                </div>
            </div>

            <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <?php if($item->gambar): ?>
                        <img src="<?php echo e(asset('storage/forum/' . $item->gambar)); ?>" alt="foto" class="card-img-top"
                            style="height: 300px; object-fit: cover;">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($item->judul); ?></h5>
                        <p class="card-text"><?php echo \Illuminate\Support\Str::limit(strip_tags($item->content), 400, '...'); ?></p>
                        <a href="<?php echo e(route('user.dataforum.detail', $item->id)); ?>" class="btn btn-primary">Selengkapnya...</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
</section>
<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/forum/forum-siswa.blade.php ENDPATH**/ ?>