<?php $__env->startSection('title', 'Notifikasi'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Semua Notifikasi</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/admin/dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item active">Semua Notifikasi</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mt-3 mb-3">
                                <h5 class="card-title"></h5>
                            </div>


                            <!-- Table with hoverable rows -->
                            <table class="table table-hover">
                                <tbody id="notificationTable">
                                    <?php if($beritaforumNotifications->count() > 0): ?>
                                        <?php $__currentLoopData = $databeritaforumNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr data-id="<?php echo e($item->data['berita_id'] ?? $item->data['forum_id']); ?>" data-type="<?php echo e($item->data['type']); ?>"
                                                style="cursor: pointer;">
                                                <td>
                                                    <?php if($item->data['type'] == 'berita'): ?>
                                                        <?php echo e($item->data['type']); ?>

                                                    <?php elseif($item->data['type'] == 'forum'): ?>
                                                        <?php echo e($item->data['type']); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <h5 style="font-size: 20px; margin-bottom: 0; font-weight: 600; color: #012970;">
                                                        <?php echo e($item->data['judul']); ?></h5>
                                                    <br>
                                                    <?php echo \Illuminate\Support\Str::limit(strip_tags($item->data['content']), 100, '...'); ?>

                                                </td>
                                                <td>
                                                    <?php echo e(\Carbon\Carbon::parse($item->data['created_at'])->format('d/m/Y')); ?>

                                                    <br>
                                                    <?php echo e($item->created_at->diffForHumans()); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td style="display: flex; justify-content: center; align-items: center; height: 100px;">
                                                Tidak Ada Notifikasi
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->

                        </div>
                    </div>
                </div>
            </div>

            <!-- Paginate -->
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <!-- Previous Page Link -->
                    <?php if($databeritaforumNotifications->onFirstPage()): ?>
                        <li class="page-item disabled"><span class="page-link">Previous</span></li>
                    <?php else: ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($databeritaforumNotifications->previousPageUrl()); ?>">Previous</a>
                        </li>
                    <?php endif; ?>

                    <!-- Pagination Elements -->
                    <?php for($i = 1; $i <= $databeritaforumNotifications->lastPage(); $i++): ?>
                        <li class="page-item <?php echo e($i == $databeritaforumNotifications->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($databeritaforumNotifications->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>

                    <!-- Next Page Link -->
                    <?php if($databeritaforumNotifications->hasMorePages()): ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($databeritaforumNotifications->nextPageUrl()); ?>">Next</a></li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link">Next</span></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <!-- End Paginate -->
        </section>

    </main><!-- End #main -->

    <script>
        document.getElementById('notificationTable').addEventListener('click', function(event) {
            var target = event.target;
            while (target && target.nodeName !== 'TR') {
                target = target.parentNode;
            }
            if (target) {
                var id = target.getAttribute('data-id');
                var type = target.getAttribute('data-type');
                var url = '';

                console.log('Clicked row:', target);
                console.log('ID:', id);
                console.log('Type:', type);

                <?php if(auth()->user()->level == 'admin'): ?>
                    if (type === 'berita') {
                        url = 'databerita/detail/' + id; // Sesuaikan dengan route berita Anda
                    } else if (type === 'forum') {
                        url = 'dataforum/detail/' + id; // Sesuaikan dengan route forum Anda
                    }
                <?php elseif(auth()->user()->level == 'siswa'): ?>
                    if (type === 'berita') {
                        url = 'berita/detail/' + id; // Sesuaikan dengan route berita Anda
                    } else if (type === 'forum') {
                        url = 'forumdiskusi/detail/' + id; // Sesuaikan dengan route forum Anda
                    }
                <?php endif; ?>

                if (url) {
                    window.location.href = url;
                }
            }
        });
    </script>



    <!-- Tambahkan JavaScript untuk menghapus parameter pencarian saat halaman di-refresh -->
    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('search');
            url.searchParams.delete('kelas');
            url.searchParams.delete('jurusan');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/notification.blade.php ENDPATH**/ ?>