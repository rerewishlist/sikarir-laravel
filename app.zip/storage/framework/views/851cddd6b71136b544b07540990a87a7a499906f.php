<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title><?php echo $__env->yieldContent('title', 'Title'); ?></title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <?php echo $__env->make('layouts.partial-guest.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="service-details-page">

    <header id="header" class="header d-flex align-items-center sticky-top">
        <?php echo $__env->make('layouts.partial-guest.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content-guest'); ?>

        <?php if(!isset($hideFooter) || !$hideFooter): ?>
            <?php echo $__env->make('layouts.partial-guest.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <!-- Scroll Top -->
        <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

        <!-- Preloader -->
        <div id="preloader"></div>

        <?php echo $__env->make('layouts.partial-guest.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/layouts/content-guest.blade.php ENDPATH**/ ?>