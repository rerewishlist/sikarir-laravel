<div>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div wire:poll>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="chat <?php if($message->from_user_id == auth()->id()): ?> chat-end <?php else: ?> chat-start <?php endif; ?>">
                                <div class="chat-image avatar">
                                    <div class="w-10 rounded-full">
                                        <img alt="Tailwind CSS chat bubble component"
                                            src="https://img.daisyui.com/images/stock/photo-1534528741775-53994a69daeb.jpg" />
                                    </div>
                                </div>
                                <div class="chat-header">
                                    <?php echo e($message->fromUser->name); ?>

                                    <time class="text-xs opacity-50"><?php echo e($message->created_at->diffForHumans()); ?></time>
                                </div>
                                <div class="chat-bubble"><?php echo e($message->message); ?></div>
                                <div class="chat-footer opacity-50">
                                    Delivered
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="form-control">
                        <form action="" wire:submit.prevent="sendMessage">
                            <textarea class="textarea textarea-bordered w-full" wire:model="message" placeholder="send your message..."></textarea>
                            <button type="submit" class="btn btn-primary">Send</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\BreezeChatFix\resources\views/livewire/chat.blade.php ENDPATH**/ ?>