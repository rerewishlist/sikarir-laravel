<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Data Siswa</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/admin/dashboard">Home</a></li>
                    <li class="breadcrumb-item active">Data Siswa</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Table Data Siswa</h5>

                            <!-- Button Modal Tambah Siswa-->
                            <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                data-bs-target="#basicModal">
                                <i class="bi bi-plus me-1"></i> Tambah Data
                            </button>
                            <!-- End button Modal Tambah Siswa -->

                            <!-- Table with hoverable rows -->
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width: 1%" scope="col">No</th>
                                        <th style="width: 9%" scope="col">NIS</th>
                                        <th style="width: 20%" scope="col">Nama</th>
                                        <th style="width: 15%" scope="col" colspan="3">Kelas Jurusan</th>
                                        <th style="width: 1%"scope="col">Jenis Kelamin</th>
                                        <th style="width: 9%"scope="col">Tempat Lahir</th>
                                        <th style="width: 10%"scope="col">Tanggal Lahir</th>
                                        <th style="width: 10%"scope="col">Alamat</th>
                                        <th style="width: 10%"scope="col">No HP</th>
                                        <th style="width: 10%" scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row">
                                                <?php echo e(($users->currentPage() - 1) * $users->perPage() + $loop->iteration); ?>

                                            </th>
                                            <td><?php echo e($item->nis); ?></td>
                                            <td><?php echo e($item->nama); ?></td>
                                            <td><?php echo e($item->kelas); ?></td>
                                            <td><?php echo e($item->nama_jurusan); ?></td>
                                            <td><?php echo e($item->subkelas); ?></td>
                                            <td><?php echo e($item->jenis_kelamin); ?></td>
                                            <td><?php echo e($item->tempat_lahir); ?></td>
                                            <td><?php echo e($item->tanggal_lahir); ?></td>
                                            <td><?php echo e($item->alamat); ?></td>
                                            <td><?php echo e($item->nohp); ?></td>
                                            <td>

                                                <!-- Button Modal Edit Siswa-->
                                                <button type="button" class="btn btn-info" data-bs-toggle="modal"
                                                    data-bs-target="#detailModal<?php echo e($item->id); ?>">
                                                    <i class="bi bi-info-circle"></i>
                                                </button>
                                                <!-- End Button Modal Edit Siswa-->

                                                <!-- Button Modal Hapus Siswa-->
                                                <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                                    data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                                <!-- End Button Modal Hapus Siswa-->

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->

                        </div>
                    </div>
                </div>
            </div>

            <!-- Paginate -->
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <!-- Previous Page Link -->
                    <?php if($users->onFirstPage()): ?>
                        <li class="page-item disabled"><span class="page-link">Previous</span></li>
                    <?php else: ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($users->previousPageUrl()); ?>">Previous</a>
                        </li>
                    <?php endif; ?>

                    <!-- Pagination Elements -->
                    <?php for($i = 1; $i <= $users->lastPage(); $i++): ?>
                        <li class="page-item <?php echo e($i == $users->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($users->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>

                    <!-- Next Page Link -->
                    <?php if($users->hasMorePages()): ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($users->nextPageUrl()); ?>">Next</a></li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link">Next</span></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <!-- End Paginate -->
        </section>

        <!-- Modal Tambah Siswa-->
        <div class="modal fade" id="basicModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Data Siswa Baru</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="formTambahSiswa" class="row g-3" action="<?php echo e(route('datasiswa.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        id="floatingNama" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="Nama"
                                        required>
                                    <label for="floatingNama">Nama</label>
                                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input class="form-control <?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        id="floatingNis" name="nis" value="<?php echo e(old('nis')); ?>" placeholder="NIS"
                                        required>
                                    <label for="floatingNis">NIS</label>
                                    <?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <select class="form-select <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingSelect"
                                        aria-label="Level" name="level" placeholder="Level" required>
                                        <option value="siswa" <?php echo e(old('level') == 'siswa' ? 'selected' : ''); ?> selected>
                                            Siswa</option>
                                    </select>
                                    <label for="floatingSelect">Level</label>
                                    <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password"
                                        id="floatingPassword" name="password" value="<?php echo e(old('password')); ?>"
                                        placeholder="Password" required>
                                    <label for="floatingPassword">Password</label>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <select class="form-select <?php $__errorArgs = ['jurusan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="floatingSelectJurusan" aria-label="Jurusan" name="jurusan_id"
                                        placeholder="Jurusan" required>
                                        <option value="" disabled selected>Pilih Jurusan</option>
                                        <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($jurusan->id); ?>"
                                                <?php echo e(old('jurusan_id') == $jurusan->id ? 'selected' : ''); ?>>
                                                <?php echo e($jurusan->nama); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="floatingSelectJurusan">Jurusan</label>
                                    <?php $__errorArgs = ['jurusan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-floating">
                                    <select class="form-select <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="floatingSelectKelas" aria-label="Kelas" name="kelas" placeholder="Kelas"
                                        required>
                                        <option value="kelas" disabled selected>Kelas</option>
                                        <option value="10" <?php echo e(old('kelas') == '10' ? 'selected' : ''); ?>>10</option>
                                        <option value="11" <?php echo e(old('kelas') == '11' ? 'selected' : ''); ?>>11</option>
                                        <option value="12" <?php echo e(old('kelas') == '12' ? 'selected' : ''); ?>>12</option>
                                    </select>
                                    <label for="floatingSelectKelas">Kelas</label>
                                    <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <select class="form-select <?php $__errorArgs = ['subkelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="floatingSelectSubkelas" aria-label="Subkelas" name="subkelas"
                                        placeholder="Kelas" required>
                                        <option value="Subkelas" disabled selected>Subkelas</option>
                                        <option value="A" <?php echo e(old('subkelas') == 'A' ? 'selected' : ''); ?>>A</option>
                                        <option value="B" <?php echo e(old('subkelas') == 'B' ? 'selected' : ''); ?>>B</option>
                                        <option value="C" <?php echo e(old('subkelas') == 'C' ? 'selected' : ''); ?>>C</option>
                                    </select>
                                    <label for="floatingSelectSubkelas">Subkelas</label>
                                    <?php $__errorArgs = ['subkelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <select class="form-select <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="floatingSelectJenisKelamin" aria-label="Jenis Kelamin" name="jenis_kelamin"
                                        placeholder="Kelas" required>
                                        <option value="Jenis Kelamin" disabled selected>Jenis Kelamin
                                        </option>
                                        <option value="L" <?php echo e(old('jenis_kelamin') == 'L' ? 'selected' : ''); ?>>L
                                        </option>
                                        <option value="P" <?php echo e(old('jenis_kelamin') == 'P' ? 'selected' : ''); ?>>P
                                        </option>
                                    </select>
                                    <label for="floatingSelectJenisKelamin">Jenis Kelamin</label>
                                    <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <input class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        id="floatingTempatLahir" name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>"
                                        placeholder="Tempat Lahir" required>
                                    <label for="floatingTempatLahir">Tempat Lahir</label>
                                    <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <input class="form-control <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        type="date" id="floatingTanggalLahir" name="tanggal_lahir"
                                        value="<?php echo e(old('tanggal_lahir')); ?>" placeholder="Tanggal Lahir" required>
                                    <label for="floatingTanggalLahir">Tanggal Lahir</label>
                                    <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <textarea class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingAlamat" name="alamat"
                                        placeholder="Alamat" required><?php echo e(old('alamat')); ?></textarea>
                                    <label for="floatingAlamat">Alamat</label>
                                    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input class="form-control <?php $__errorArgs = ['nohp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        id="floatingNoHP" name="nohp" value="<?php echo e(old('nohp')); ?>"
                                        placeholder="No HP" required>
                                    <label for="floatingNoHP">No HP</label>
                                    <?php $__errorArgs = ['nohp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Modal Tambah Siswa-->

        <!-- Modal Edit Siswa-->
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="detailModal<?php echo e($item->id); ?>" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Data Siswa</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="formEditSiswa<?php echo e($item->id); ?>" class="row g-3"
                                action="<?php echo e(route('datasiswa.update', $item->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="col-md-12">
                                    <div class="form-floating">
                                        <input class="form-control <?php $__errorArgs = ['namaupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            type="text" id="floatingNama" name="namaupdate"
                                            value="<?php echo e($item->nama); ?>" placeholder="Nama" required>
                                        <label for="floatingNama">Nama</label>
                                        <?php $__errorArgs = ['namaupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input class="form-control <?php $__errorArgs = ['nisupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            type="text" id="floatingNis" name="nisupdate"
                                            value="<?php echo e($item->nis); ?>" placeholder="NIS" required>
                                        <label for="floatingNis">NIS</label>
                                        <?php $__errorArgs = ['nisupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <select class="form-select <?php $__errorArgs = ['levelupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="floatingSelect" aria-label="Level" name="levelupdate"
                                            placeholder="Level" required>
                                            <option value="siswa" <?php echo e($item->level == 'siswa' ? 'selected' : ''); ?>

                                                selected>
                                                Siswa</option>

                                        </select>
                                        <label for="floatingSelect">Level</label>
                                        <?php $__errorArgs = ['levelupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <select class="form-select" id="floatingSelectJurusan" aria-label="Jurusan"
                                            name="jurusan_idupdate" required>
                                            <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($jurusan->id); ?>"
                                                    <?php echo e($item->jurusan_id == $jurusan->id ? 'selected' : ''); ?>>
                                                    <?php echo e($jurusan->nama); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="floatingSelectJurusan">Jurusan</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <select class="form-select" id="floatingSelectKelas" aria-label="Kelas"
                                            name="kelasupdate" required>
                                            <option value="10" <?php echo e($item->kelas == '10' ? 'selected' : ''); ?>>10
                                            </option>
                                            <option value="11" <?php echo e($item->kelas == '11' ? 'selected' : ''); ?>>11
                                            </option>
                                            <option value="12" <?php echo e($item->kelas == '12' ? 'selected' : ''); ?>>12
                                            </option>
                                        </select>
                                        <label for="floatingSelectKelas">Kelas</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <select class="form-select" id="floatingSelectSubkelas" aria-label="Subkelas"
                                            name="subkelasupdate" required>
                                            <option value="A" <?php echo e($item->subkelas == 'A' ? 'selected' : ''); ?>>A
                                            </option>
                                            <option value="B" <?php echo e($item->subkelas == 'B' ? 'selected' : ''); ?>>B
                                            </option>
                                            <option value="C" <?php echo e($item->subkelas == 'C' ? 'selected' : ''); ?>>C
                                            </option>
                                        </select>
                                        <label for="floatingSelectSubkelas">Subkelas</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <select class="form-select" id="floatingSelectJenisKelamin"
                                            aria-label="Jenis Kelamin" name="jenis_kelaminupdate" required>
                                            <option value="L" <?php echo e($item->jenis_kelamin == 'L' ? 'selected' : ''); ?>>L
                                            </option>
                                            <option value="P" <?php echo e($item->jenis_kelamin == 'P' ? 'selected' : ''); ?>>P
                                            </option>
                                        </select>
                                        <label for="floatingSelectJenisKelamin">Jenis Kelamin</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input class="form-control <?php $__errorArgs = ['tempat_lahirupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            type="text" id="floatingTempatLahir" name="tempat_lahirupdate"
                                            value="<?php echo e($item->tempat_lahir); ?>" placeholder="Tempat Lahir" required>
                                        <label for="floatingTempatLahir">Tempat Lahir</label>
                                        <?php $__errorArgs = ['tempat_lahirupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input class="form-control <?php $__errorArgs = ['tanggal_lahirupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            type="date" id="floatingTanggalLahir" name="tanggal_lahirupdate"
                                            value="<?php echo e($item->tanggal_lahir); ?>" placeholder="Tanggal Lahir" required>
                                        <label for="floatingTanggalLahir">Tanggal Lahir</label>
                                        <?php $__errorArgs = ['tanggal_lahirupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <textarea class="form-control <?php $__errorArgs = ['alamatupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingAlamat" name="alamatupdate"
                                            placeholder="Alamat" required><?php echo e($item->alamat); ?></textarea>
                                        <label for="floatingAlamat">Alamat</label>
                                        <?php $__errorArgs = ['alamatupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input class="form-control <?php $__errorArgs = ['nohpupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            type="text" id="floatingNoHP" name="nohpupdate"
                                            value="<?php echo e($item->nohp); ?>" placeholder="No HP" required>
                                        <label for="floatingNoHP">No HP</label>
                                        <?php $__errorArgs = ['nohpupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- End Modal Edit Siswa-->

        <!-- Modal Hapus Siswa-->
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="deleteModal<?php echo e($item->id); ?>" tabindex="-1"
                aria-labelledby="deleteModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="deleteModalLabel<?php echo e($item->id); ?>">Konfirmasi
                                Hapus</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Apakah Anda yakin ingin menghapus data "<?php echo e($item->nama); ?>"?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <form action="<?php echo e(route('datasiswa.destroy', $item->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- End Modal Hapus Siswa-->


    </main><!-- End #main -->

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // AJAX untuk form tambah siswa
            document.getElementById('formTambahSiswa').addEventListener('submit', function(e) {
                e.preventDefault();
                var form = this;

                fetch(form.action, {
                        method: form.method,
                        body: new FormData(form),
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.errors) {
                            // Tampilkan pesan kesalahan
                            Object.keys(data.errors).forEach(function(key) {
                                var input = document.querySelector(`[name="${key}"]`);
                                input.classList.add('is-invalid');
                                var feedback = input.nextElementSibling;
                                feedback.textContent = data.errors[key][0];
                                feedback.style.display = 'block';
                            });
                        } else {
                            // Sukses, redirect ke halaman yang diinginkan
                            window.location.href = data.redirect;
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });;
            });

            // AJAX untuk form edit siswa
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                document.getElementById('formEditSiswa<?php echo e($item->id); ?>').addEventListener('submit', function(
                    e) {
                    e.preventDefault();
                    var form = this;

                    fetch(form.action, {
                            method: form.method,
                            body: new FormData(form),
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.errors) {
                                // Tampilkan pesan kesalahan
                                Object.keys(data.errors).forEach(function(key) {
                                    var input = document.querySelector(`[name="${key}"]`);
                                    input.classList.add('is-invalid');
                                    var feedback = input.nextElementSibling;
                                    feedback.textContent = data.errors[key][0];
                                    feedback.style.display = 'block';
                                });
                            } else {
                                // Sukses, redirect ke halaman yang diinginkan
                                window.location.href = data.redirect;
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                        });
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Ambil pesan sukses dari sessionStorage jika ada
            var successMessage = sessionStorage.getItem('successMessage');
            if (successMessage) {
                // Tampilkan pesan sukses
                var alertDiv = document.createElement('div');
                alertDiv.classList.add('alert', 'alert-primary', 'alert-dismissible', 'fade', 'show');
                alertDiv.setAttribute('role', 'alert');
                alertDiv.innerHTML = successMessage +
                    '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                document.body.insertBefore(alertDiv, document.body.firstChild);
                sessionStorage.removeItem('successMessage');
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/admin/data-siswa.blade.php ENDPATH**/ ?>