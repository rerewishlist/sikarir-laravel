<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 3.0.5
    </div>
    <strong>Copyright &copy; 2024 <a href="#">Company</a>.</strong> All rights reserved.
</footer>
<?php /**PATH C:\xampp\htdocs\BreezeChatFix\resources\views/layouts/footer.blade.php ENDPATH**/ ?>