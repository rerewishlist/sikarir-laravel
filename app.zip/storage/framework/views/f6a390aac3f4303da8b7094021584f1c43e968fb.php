<?php $__env->startSection('title', 'Chat Admin'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Chat Admin</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Chat Admin</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="justify-content-between align-items-center mt-3">
                                <!-- Form Pencarian -->
                                <form method="GET" action="<?php echo e(url('/siswa/chat')); ?>" class="d-flex search-form">
                                    <input style="margin-right: 10px;" type="text" name="search" class="form-control"
                                        placeholder="Cari data nama admin..." value="<?php echo e(request('search')); ?>">

                                    <button type="submit" class="btn btn-primary">Cari</button>
                                </form>
                                <!-- End Form Pencarian -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section class="section dashboard">
            <div class="row">

                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Card with an image on top -->
                    <div class="col-lg-3">
                        <div class="card text-center">
                            <?php if($item->foto): ?>
                                <img src="<?php echo e(asset('storage/foto/' . $item->foto)); ?>" alt="foto" class="card-img-top"
                                    style="height: 300px; object-fit: cover;">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/img/blank-profile-picture.jpg')); ?>" alt="foto" class="card-img-top"
                                    style="height: 300px; object-fit: cover;">
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title" style="height: 2cm"><?php echo e($item->nama); ?></h5>
                                <a href="<?php echo e(route('user.chat.detail', $item->id)); ?>" class="btn btn-primary">Kirim
                                    Pesan</a>
                            </div>
                        </div>
                    </div><!-- End Card with an image on top -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </section>
    </main><!-- End #main -->

    <!-- Tambahkan JavaScript untuk menghapus parameter pencarian saat halaman di-refresh -->
    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('search');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/admin/data-admin.blade.php ENDPATH**/ ?>