<?php $__env->startSection('title', 'Detail Materi'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Detail Materi</h1>
            <nav>
                <ol class="breadcrumb">
                    <?php if(auth()->user()->level == 'admin'): ?>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('datamateri.view')); ?>">Data Materi</a></li>
                    <?php elseif(auth()->user()->level == 'siswa'): ?>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('user.materi')); ?>">Materi</a></li>
                    <?php endif; ?>
                    <li class="breadcrumb-item active"><?php echo e($materi->judul); ?></li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Card with header and footer -->
                    <div class="card mb-3">

                        <div class="card-body">
                            <h5 class="card-title mb-0" style="font-size: 30px;"><?php echo e($materi->judul); ?></h5>
                            <div class="content-justify mt-0" style="text-align: justify; font-size: 15px;">by <?php echo e($materi->admin->nama); ?> |
                                <?php echo e($materi->created_at->translatedFormat('l, j F Y, H:i A')); ?>

                                <hr>
                            </div>
                            <div class="content-justify mb-2" style="text-align: justify;">
                                <?php echo $materi->deskripsi; ?>

                            </div>
                            <span>
                                <?php if($materi->file_pendukung): ?>
                                    <?php
                                        $fileExtension = pathinfo($materi->file_pendukung, PATHINFO_EXTENSION);
                                    ?>
                                    <div class="d-flex align-items-center">
                                        <?php if(in_array($fileExtension, ['pdf'])): ?>
                                            <i class="bi bi-file-pdf text-danger" style="font-size: 24px;"></i>
                                            <a href="<?php echo e(asset('storage/materi/' . $materi->file_pendukung)); ?>" class="ms-2" target="_blank">
                                                <?php echo e($materi->file_pendukung); ?>

                                            </a>
                                        <?php elseif(in_array($fileExtension, ['doc', 'docx'])): ?>
                                            <i class="bi bi-file-word text-primary" style="font-size: 24px;"></i>
                                            <a href="<?php echo e(asset('storage/materi/' . $materi->file_pendukung)); ?>" class="ms-2" target="_blank">
                                                <?php echo e($materi->file_pendukung); ?>

                                            </a>
                                        <?php elseif(in_array($fileExtension, ['jpg', 'jpeg', 'png'])): ?>
                                            <img src="<?php echo e(asset('storage/materi/' . $materi->file_pendukung)); ?>" alt="Gambar berita" class="img-thumbnail mb-2"
                                                style="max-width: 500px; max-height: 500px; object-fit: cover;">
                                        <?php else: ?>
                                            <i class="bi bi-file-text" style="font-size: 24px;"></i>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </span>
                            <p><span></span></p>
                            <div class="content-justify" style="text-align: justify;">
                                <?php echo $materi->content; ?>

                            </div>
                        </div>
                    </div><!-- End Card with header and footer -->

                </div>
            </div>
        </section>

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/materi/detail-materi.blade.php ENDPATH**/ ?>