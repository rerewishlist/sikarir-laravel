<?php $__env->startSection('title', 'Chat Page'); ?>
<?php $__env->startSection('menuChat', 'active'); ?>
<?php $__env->startSection('content-guest'); ?>

    <main class="main">

        <!-- Page Title -->
        <div class="page-title" data-aos="fade">
            <div class="container d-lg-flex justify-content-between align-items-center">
                <h1 class="mb-2 mb-lg-0">Chatting</h1>
                <nav class="breadcrumbs">
                    <ol>
                        <li><a href="<?php echo e(Route('dashboard')); ?>">Home</a></li>
                        <li class="current">Chatting</li>
                    </ol>
                </nav>
            </div>
        </div><!-- End Page Title -->

        <!-- Service Details Section -->
        <section id="service-details" class="service-details section">
            <div class="container">
                <div class="row gy-5">
                    <div class="col-lg-3" data-aos="fade-up" data-aos-delay="100">
                        <div class="service-box">
                            <h4>List Admin</h4>
                            <div class="services-list">
                                <?php $__currentLoopData = $alladmins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('user.chat.view', ['admin_id' => $item->id])); ?>"
                                        class="<?php echo e(request()->get('admin_id') == $item->id ? 'active' : ''); ?>">
                                        <i class="bi bi-arrow-right-circle"></i><span><?php echo e($item->nama); ?></span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div><!-- End Services List -->
                    </div>

                    <?php if($admins->isNotEmpty()): ?>
                        <div class="col-lg-9 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-5">
                                    <h3><?php echo e($item->nama); ?></h3>
                                    <hr>

                                    <?php if($item->foto): ?>
                                        <img src="<?php echo e(asset('storage/foto/' . $item->foto)); ?>" alt="Foto Admin" class="img-fluid-foto services-img">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/img/blank-profile-picture.jpg')); ?>" alt="Foto Admin"
                                            class="img-fluid-foto services-img">
                                    <?php endif; ?>

                                    <p>
                                        <button onclick="location.href='<?php echo e(route('user.chat.detail', $item->id)); ?>'" class="btn btn-primary">Chat
                                            sekarang</button>
                                    </p>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section><!-- /Service Details Section -->

    </main>

    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('admin_id');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/chat/data-chat-siswa.blade.php ENDPATH**/ ?>