<!DOCTYPE html>
<html>
<head>
    <title>Forums</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Forums</h1>
        <div class="list-group">
            <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item">
                    <h2><?php echo e($forum->title); ?></h2>
                    <p><?php echo e(Str::limit($forum->body, 150)); ?></p>
                    <p>Posted by
                        <?php if($forum->user): ?>
                            <?php echo e($forum->user->nama); ?>

                        <?php elseif($forum->admin): ?>
                            <?php echo e($forum->admin->nama); ?>

                        <?php endif; ?>
                    </p>
                    <a href="<?php echo e(route('forums.show', $forum->id)); ?>" class="btn btn-primary">View</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/forum/index.blade.php ENDPATH**/ ?>