<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
        &copy; 2024 <strong><span>EduMentor</span></strong>. Ver. 2024.1.1
    </div>
</footer><!-- End Footer -->
<?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/layouts/partial/footer.blade.php ENDPATH**/ ?>