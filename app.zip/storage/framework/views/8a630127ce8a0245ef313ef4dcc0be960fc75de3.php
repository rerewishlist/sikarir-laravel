<?php $__env->startSection('title', 'Berita Page'); ?>
<?php $__env->startSection('menuBerita', 'active'); ?>
<?php $__env->startSection('content-guest'); ?>

    <main class="main">

        <!-- Page Title -->
        <div class="page-title" data-aos="fade">
            <div class="container d-lg-flex justify-content-between align-items-center">
                <h1 class="mb-2 mb-lg-0">Berita Terbaru</h1>
                <nav class="breadcrumbs">
                    <ol>
                        <li><a href="<?php echo e(Route('landing')); ?>">Home</a></li>
                        <li class="current">Berita</li>
                    </ol>
                </nav>
            </div>
        </div><!-- End Page Title -->

        <!-- Service Details Section -->
        <section id="service-details" class="service-details section">

            <div class="container">

                <div class="row gy-5">

                    <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">

                        <div class="service-box">
                            <div class="services-list">
                                <form action="">
                                    <input type="text" name="search_berita" class="form-control" placeholder="Cari judul berita..."
                                        value="<?php echo e(request('search_berita')); ?>">
                                    <button type="submit" class="btn btn-primary mt-3">Cari</button>
                                </form>
                            </div>
                        </div><!-- End Services List -->

                        <div class="service-box">
                            <h4>List Kategori</h4>
                            <div class="services-list">
                                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('berita.menu', ['kategori_id' => $item->id])); ?>"
                                        class="<?php echo e(request()->get('kategori_id') == $item->id ? 'active' : ''); ?>">
                                        <i class="bi bi-arrow-right-circle"></i><span><?php echo e($item->nama); ?></span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div><!-- End Services List -->

                    </div>
                    <div class="col-lg-8 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
                        <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-5">
                                <h3><?php echo e($item->judul); ?></h3>
                                <?php
                                    $randomImages = [
                                        'assets/img/berita1.jpeg',
                                        'assets/img/berita2.jpeg',
                                        'assets/img/berita3.jpeg',
                                        'assets/img/berita4.jpeg',
                                        'assets/img/berita5.jpeg',
                                    ];
                                    $randomImage = $randomImages[array_rand($randomImages)];
                                ?>
                                <?php if($item->gambar): ?>
                                    <img src="<?php echo e(asset('storage/berita/' . $item->gambar)); ?>" alt="Gambar berita" class="img-fluid services-img">
                                <?php else: ?>
                                    <img src="<?php echo e(asset($randomImage)); ?>" alt="Gambar berita" class="img-fluid services-img">
                                <?php endif; ?>
                                <p>
                                    <?php $__currentLoopData = $item->kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge bg-primary"><?php echo e($kategori->nama); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                                <p>
                                    <?php echo e($item->created_at->translatedFormat('d F Y')); ?>

                                </p>
                                <p>
                                    <?php echo \Illuminate\Support\Str::limit(strip_tags($item->content), 300, '...'); ?>

                                </p>
                                <a href="<?php echo e(Route('berita.detail.menu', $item->slug)); ?>">Selengkapnya...</a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Paginate -->
                        <nav aria-label="Page navigation example">
                            <ul class="pagination">
                                <!-- Previous Page Link -->
                                <?php if($beritas->onFirstPage()): ?>
                                    <li class="page-item disabled"><span class="page-link">Previous</span></li>
                                <?php else: ?>
                                    <li class="page-item"><a class="page-link" href="<?php echo e($beritas->previousPageUrl()); ?>">Previous</a>
                                    </li>
                                <?php endif; ?>

                                <!-- Pagination Elements -->
                                <?php for($i = 1; $i <= $beritas->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($i == $beritas->currentPage() ? 'active' : ''); ?>">
                                        <a class="page-link" href="<?php echo e($beritas->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>

                                <!-- Next Page Link -->
                                <?php if($beritas->hasMorePages()): ?>
                                    <li class="page-item"><a class="page-link" href="<?php echo e($beritas->nextPageUrl()); ?>">Next</a></li>
                                <?php else: ?>
                                    <li class="page-item disabled"><span class="page-link">Next</span></li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <!-- End Paginate -->

                    </div>

                </div>

            </div>


        </section><!-- /Service Details Section -->

    </main>

    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('kategori_id');
            url.searchParams.delete('search_berita');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/menu-berita.blade.php ENDPATH**/ ?>