<?php $__env->startSection('title', 'Data Jurusan'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Data Jurusan</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Data Jurusan</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">

                <?php echo $__env->make('jurusan.modal.tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="card-title">Table Data Jurusan</h5>
                                <!-- Form Pencarian -->
                                <form method="GET" action="<?php echo e(url('/admin/datajurusan')); ?>" class="d-flex search-form">
                                    <input style="margin-right: 10px;" type="text" name="search_jurusan" class="form-control"
                                        placeholder="Cari data jurusan..." value="<?php echo e(request('search_jurusan')); ?>">
                                    <button type="submit" class="btn btn-primary">Cari</button>
                                </form>
                                <!-- End Form Pencarian -->
                            </div>

                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width: 1%" scope="col">No</th>
                                        <th style="width: 19%" scope="col">Nama</th>
                                        <th style="width: 60%" scope="col">Deskripsi</th>
                                        <th style="width: 20%" scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <?php if($jurusans->count() > 0): ?>
                                    <tbody>
                                        <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row">
                                                    <?php echo e(($jurusans->currentPage() - 1) * $jurusans->perPage() + $loop->iteration); ?>

                                                </th>
                                                <td><?php echo e($item->nama); ?></td>
                                                <td><?php echo e($item->deskripsi); ?></td>
                                                <td>
                                                    <!-- Button Modal Edit jurusan-->
                                                    <button type="button" class="btn btn-outline-warning" data-bs-toggle="modal"
                                                        data-bs-target="#detailModal<?php echo e($item->id); ?>">
                                                        <i class="bi bi-pencil-square"></i>
                                                    </button>
                                                    <!-- End Button Modal Edit jurusan-->

                                                    <!-- Button Modal Hapus jurusan-->
                                                    <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal"
                                                        data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                    <!-- End Button Modal Hapus jurusan-->
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                <?php else: ?>
                                    <tbody>
                                        <tr>
                                            <td colspan="4" class="text-center align-middle">
                                                Tidak ada data jurusan
                                            <td>
                                        </tr>
                                    </tbody>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>

                    <!-- Paginate -->
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <!-- Previous Page Link -->
                            <?php if($jurusans->onFirstPage()): ?>
                                <li class="page-item disabled"><span class="page-link">Previous</span></li>
                            <?php else: ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($jurusans->previousPageUrl()); ?>">Previous</a>
                                </li>
                            <?php endif; ?>

                            <!-- Pagination Elements -->
                            <?php for($i = 1; $i <= $jurusans->lastPage(); $i++): ?>
                                <li class="page-item <?php echo e($i == $jurusans->currentPage() ? 'active' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($jurusans->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>

                            <!-- Next Page Link -->
                            <?php if($jurusans->hasMorePages()): ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($jurusans->nextPageUrl()); ?>">Next</a>
                                </li>
                            <?php else: ?>
                                <li class="page-item disabled"><span class="page-link">Next</span></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <!-- End Paginate -->

                </div>

            </div>
        </section>

        <?php echo $__env->make('jurusan.modal.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('jurusan.modal.hapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </main><!-- End #main -->

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // AJAX untuk form edit jurusan
            <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                document.getElementById('formEditJurusan<?php echo e($item->id); ?>').addEventListener('submit', function(
                    e) {
                    e.preventDefault();
                    var form = this;

                    fetch(form.action, {
                            method: form.method,
                            body: new FormData(form),
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.errors) {
                                // Tampilkan pesan kesalahan
                                Object.keys(data.errors).forEach(function(key) {
                                    var input = document.querySelector(`[name="${key}"]`);
                                    input.classList.add('is-invalid');
                                    var feedback = input.nextElementSibling;
                                    feedback.textContent = data.errors[key][0];
                                    feedback.style.display = 'block';
                                });
                            } else {
                                // Sukses, redirect ke halaman yang diinginkan
                                window.location.href = data.redirect;
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                        });
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        });
    </script>

    <!-- Tambahkan JavaScript untuk menghapus parameter pencarian saat halaman di-refresh -->
    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('search_jurusan');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/jurusan/data-jurusan.blade.php ENDPATH**/ ?>