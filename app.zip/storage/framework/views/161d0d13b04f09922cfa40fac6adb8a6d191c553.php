<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title">Table Data Forum Diskusi</h5>
                        <!-- Form Pencarian -->
                        <form method="GET" action="<?php echo e(url('/admin/dataforum')); ?>" class="d-flex search-form">
                            <input style="margin-right: 10px;" type="text" name="search_forum" class="form-control" placeholder="Cari data foru..."
                                value="<?php echo e(request('search_forum')); ?>">

                            <?php
                                $uniqueDates = collect($dates)
                                    ->map(function ($date) {
                                        return \Carbon\Carbon::parse($date)->format('Y-m');
                                    })
                                    ->unique();
                            ?>

                            <select name="filter_tanggal" class="form-control" style="margin-right: 10px;">
                                <option value="">-- Pilih Bulan dan Tahun --</option>
                                <?php $__currentLoopData = $uniqueDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($date); ?>" <?php echo e(request('filter_tanggal') == $date ? 'selected' : ''); ?>>
                                        <?php echo e(\Carbon\Carbon::parse($date)->format('F Y')); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <button type="submit" class="btn btn-primary">Cari</button>
                        </form>
                        <!-- End Form Pencarian -->
                    </div>

                    <!-- Button Modal Tambah Forum-->
                    <a href="<?php echo e(route('admin.dataforum.create')); ?>" class="btn btn-success mb-3">
                        <i class="bi bi-plus me-1"></i> Buat Forum
                    </a>
                    <!-- End button Modal Tambah Forum -->

                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th style="width: 1%" scope="col">No</th>
                                <th style="width: 15%" scope="col">Judul</th>
                                <th style="width: 16%" scope="col">Thumbnail</th>
                                <th style="width: 10%" scope="col">Author</th>
                                <th style="width: 5%" scope="col">Balasan</th>
                                <th style="width: 20%" scope="col">Content</th>
                                <th style="width: 10%"scope="col">Tanggal</th>
                                <th style="width: 20%" scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row">
                                        <?php echo e(($forums->currentPage() - 1) * $forums->perPage() + $loop->iteration); ?>

                                    </th>
                                    <td><?php echo e($item->judul); ?></td>
                                    <td>
                                        <?php if($item->gambar): ?>
                                            <img src="<?php echo e(asset('storage/forum/' . $item->gambar)); ?>" alt="Gambar forum" class="img-thumbnail mt-2"
                                                style="width: 150px; height: 150px; object-fit: cover;">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->admin): ?>
                                            Admin : <?php echo e($item->admin->nama); ?>

                                        <?php elseif($item->user): ?>
                                            Siswa : <?php echo e($item->user->nama); ?>

                                        <?php else: ?>
                                            Unknown
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->comments->count()); ?></td>
                                    <td><?php echo \Illuminate\Support\Str::limit(strip_tags($item->content), 150, '...'); ?></td>
                                    <td><?php echo e($item->created_at->translatedFormat('d F Y')); ?></td>
                                    <td>
                                        <!-- Button Chat-->
                                        <button type="button" class="btn btn-warning"
                                            onclick="window.location.href='<?php echo e(route('admin.dataforum.edit', $item->id)); ?>'">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        <!-- End Chat-->

                                        <!-- Button Chat-->
                                        <button type="button" class="btn btn-info"
                                            onclick="window.location.href='<?php echo e(route('admin.dataforum.detail', $item->id)); ?>'">
                                            <i class="bi bi-info-circle"></i>
                                        </button>
                                        <!-- End Chat-->

                                        <!-- Button Modal Hapus Siswa-->
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                        <!-- End Button Modal Hapus Siswa-->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Paginate -->
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <!-- Previous Page Link -->
                <?php if($forums->onFirstPage()): ?>
                    <li class="page-item disabled"><span class="page-link">Previous</span></li>
                <?php else: ?>
                    <li class="page-item"><a class="page-link" href="<?php echo e($forums->previousPageUrl()); ?>">Previous</a>
                    </li>
                <?php endif; ?>

                <!-- Pagination Elements -->
                <?php for($i = 1; $i <= $forums->lastPage(); $i++): ?>
                    <li class="page-item <?php echo e($i == $forums->currentPage() ? 'active' : ''); ?>">
                        <a class="page-link" href="<?php echo e($forums->url($i)); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endfor; ?>

                <!-- Next Page Link -->
                <?php if($forums->hasMorePages()): ?>
                    <li class="page-item"><a class="page-link" href="<?php echo e($forums->nextPageUrl()); ?>">Next</a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled"><span class="page-link">Next</span></li>
                <?php endif; ?>
            </ul>
        </nav>
        <!-- End Paginate -->

    </div>

    </div>
</section>
<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/forum/forum-admin.blade.php ENDPATH**/ ?>