<?php $__env->startSection('title', 'Detail Berita'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Detail Berita</h1>
            <nav>
                <ol class="breadcrumb">
                    <?php if(auth()->user()->level == 'admin'): ?>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('databerita.view')); ?>">Data Berita</a></li>
                    <?php elseif(auth()->user()->level == 'siswa'): ?>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <?php endif; ?>
                    <li class="breadcrumb-item active"><?php echo e($berita->judul); ?></li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Card with header and footer -->
                    <div class="card mb-3">

                        <div class="card-body">
                            <h5 class="card-title" style="font-size: 30px;"><?php echo e($berita->judul); ?></h5>
                            <div class="card-body mb-3">by <?php echo e($berita->admin->nama); ?> |
                                <?php echo e($berita->created_at->translatedFormat('l, j F Y, H:i A')); ?> |
                                <?php $__currentLoopData = $berita->kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($kategori->nama); ?><?php if($index < $berita->kategoris->count() - 1): ?>
                                        ,
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <span>
                                <?php
                                    $randomImages = [
                                        'assets/img/berita1.jpeg',
                                        'assets/img/berita2.jpeg',
                                        'assets/img/berita3.jpeg',
                                        'assets/img/berita4.jpeg',
                                        'assets/img/berita5.jpeg',
                                    ];
                                    $randomImage = $randomImages[array_rand($randomImages)];
                                ?>
                                <?php if($berita->gambar): ?>
                                    <img src="<?php echo e(asset('storage/berita/' . $berita->gambar)); ?>" alt="Gambar berita" class="img-thumbnail mb-4"
                                        style="max-width: 500px; max-height: 500px; object-fit: cover;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset($randomImage)); ?>" alt="foto" class="card-img-top" style="height: 300px; object-fit: cover;">
                                <?php endif; ?>
                            </span>
                            <p><span></span></p>
                            <div class="content-justify" style="text-align: justify;">
                                <?php echo $berita->content; ?>

                            </div>
                        </div>
                    </div><!-- End Card with header and footer -->

                </div>
            </div>
        </section>

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/berita/detail-berita.blade.php ENDPATH**/ ?>