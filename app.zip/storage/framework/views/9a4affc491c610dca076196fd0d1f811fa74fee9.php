<?php $__env->startSection('title', 'Data Forum'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Data Forum Diskusi</h1>
            <nav>
                <ol class="breadcrumb">
                    <?php if(auth()->user()->level == 'admin'): ?>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <?php elseif(auth()->user()->level == 'siswa'): ?>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <?php endif; ?>
                    <li class="breadcrumb-item active">Data Forum Diskusi</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <?php if(auth()->user()->level == 'admin'): ?>
            <?php echo $__env->make('forum.forum-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('forum.modal.hapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
            <?php echo $__env->make('forum.forum-siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </main><!-- End #main -->

    <!-- Tambahkan JavaScript untuk menghapus parameter pencarian saat halaman di-refresh -->
    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('search_forum');
            url.searchParams.delete('filter_tanggal');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/forum/data-forum.blade.php ENDPATH**/ ?>