<div class="container-fluid container-xl position-relative d-flex align-items-center">

    <a href="index.html" class="logo d-flex align-items-center me-auto">
        <img src="<?php echo e(asset('assets-guest/img/logo.png')); ?>" alt="">
        <h1 class="sitename">Nama Web</h1>
    </a>

    <nav id="navmenu" class="navmenu">
        <ul>
            <li><a href="<?php echo e(Route('landing')); ?>" class="<?php echo $__env->yieldContent('menuLanding'); ?>">Home</a></li>
            <li><a href="<?php echo e(Route('berita.menu')); ?>" class="<?php echo $__env->yieldContent('menuBerita'); ?>">Berita</a></li>
            <li><a href="<?php echo e(Route('forum.menu')); ?>" class="<?php echo $__env->yieldContent('menuForum'); ?>">Forum</a></li>

            <?php
                $instansi = optional($informasi)->instansi;
            ?>
            <?php if($instansi): ?>
                <li><a href="<?php echo e(Route('contact.menu')); ?>" class="<?php echo $__env->yieldContent('menuContact'); ?>">Contact</a></li>
            <?php endif; ?>
            
            
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>

    <?php if(auth('admin')->check()): ?>
        <a class="btn-getstarted" href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(auth('admin')->user()->nama); ?></a>
    <?php elseif(auth()->check()): ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
            <a class="btn-getstarted" href="<?php echo e(route('dashboard')); ?>"><?php echo e(auth()->user()->nama); ?></a>
        <?php else: ?>
            <a class="btn-getstarted" href="/login">Login</a>
        <?php endif; ?>
    <?php else: ?>
        <a class="btn-getstarted" href="/login">Login</a>
    <?php endif; ?>

</div>
</header>
<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/layouts/partial-guest/header.blade.php ENDPATH**/ ?>