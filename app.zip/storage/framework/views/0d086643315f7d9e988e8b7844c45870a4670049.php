<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <?php if(auth()->user()->level == 'admin'): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('admin/dashboard*')); ?>" href="/admin/dashboard">
                    <i class="ri ri-home-4-line"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('admin/informasi*')); ?>" href="/admin/informasi">
                    <i class="bi bi-info-circle"></i>
                    <span>Data Informasi</span>
                </a>
            </li>

            

            <li class="nav-item">
                <a class="nav-link
                <?php if(Request::is('admin/datasiswa*')): ?> <?php echo e(setActive('admin/datasiswa*')); ?>

                <?php elseif(Request::is('admin/datajurusan')): ?> <?php echo e(setActive('admin/datajurusan*')); ?>

                <?php else: ?> collapsed <?php endif; ?>
                <?php if(Request::is('admin/datasiswa*') || Request::is('admin/datajurusan')): ?> active <?php endif; ?>"
                    data-bs-target="#siswa-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-people"></i><span>Data Siswa</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="siswa-nav" class="nav-content collapse
                <?php if(Request::is('admin/datasiswa*') || Request::is('admin/datajurusan')): ?> show <?php endif; ?>"
                    data-bs-parent="#sidebar-nav">
                    <li>
                        <a href="/admin/datasiswa" class="<?php if(Request::is('admin/datasiswa*')): ?> active <?php endif; ?>">
                            <i class="bi bi-circle"></i><span>Data Siswa</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/datajurusan" class="<?php if(Request::is('admin/datajurusan')): ?> active <?php endif; ?>">
                            <i class="bi bi-circle"></i><span>Data Jurusan</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item">
                <a class="nav-link
                <?php if(Request::is('admin/databerita*')): ?> <?php echo e(setActive('admin/databerita*')); ?>

                <?php elseif(Request::is('admin/datakategori')): ?> <?php echo e(setActive('admin/datakategori*')); ?>

                <?php else: ?> collapsed <?php endif; ?>
                <?php if(Request::is('admin/databerita*') || Request::is('admin/datakategori')): ?> active <?php endif; ?>"
                    data-bs-target="#berita-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-newspaper"></i><span>Data Berita</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="berita-nav" class="nav-content collapse
                <?php if(Request::is('admin/databerita*') || Request::is('admin/datakategori')): ?> show <?php endif; ?>"
                    data-bs-parent="#sidebar-nav">
                    <li>
                        <a href="/admin/databerita" class="<?php if(Request::is('admin/databerita*')): ?> active <?php endif; ?>">
                            <i class="bi bi-circle"></i><span>Data Berita</span>
                        </a>
                    </li>
                    <li>
                        <a href="/admin/datakategori" class="<?php if(Request::is('admin/datakategori')): ?> active <?php endif; ?>">
                            <i class="bi bi-circle"></i><span>Data Kategori</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('admin/dataforum*')); ?>" href="/admin/dataforum">
                    <i class="ri ri-discuss-line"></i>
                    <span>Data Forum</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('admin/chat*')); ?>" href="/admin/chat">
                    <i class="bi bi-chat-dots"></i>
                    <span>Data Chat</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
            </li>
            <li class="nav-item">

                <a class="nav-link <?php if(Request::is('siswa/dashboard*')): ?> <?php echo e(setActive('siswa/dashboard*')); ?> <?php elseif(Request::is('siswa/berita*')): ?> <?php echo e(setActive('siswa/berita*')); ?> <?php else: ?> collapsed <?php endif; ?>"
                    href="/siswa/dashboard">
                    <i class="ri ri-home-4-line"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('siswa/materi*')); ?>" href="/siswa/materi">
                    <i class="bi bi-blockquote-left"></i>
                    <span>Data Materi</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('siswa/forumdiskusi*')); ?>" href="/siswa/forumdiskusi">
                    <i class="ri ri-discuss-line"></i>
                    <span>Forum Diskusi</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(setActive('siswa/chat*')); ?>" href="/siswa/chat">
                    <i class="bi bi-chat-dots"></i>
                    <span>Data Chat</span>
                </a>
            </li>
        <?php endif; ?>

    </ul>

</aside><!-- End Sidebar-->
<?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/layouts/partial/sidebar.blade.php ENDPATH**/ ?>