<footer id="footer" class="footer position-relative light-background">
    <?php
        $alamat = optional($informasi)->alamat;
        $nohp = optional($informasi)->nohp;
        $email = optional($informasi)->email;
        $instansi = optional($informasi)->instansi;
        $twitter = optional($informasi)->twitter;
        $facebook = optional($informasi)->facebook;
        $instagram = optional($informasi)->instagram;
        $youtube = optional($informasi)->youtube;
        $tiktok = optional($informasi)->tiktok;
    ?>
    <?php if($instansi): ?>
        <div class="container footer-top">
            <div class="row gy-4">
                <div class="col-lg-6 col-md-6 footer-about">
                    <a href="index.html" class="logo d-flex align-items-center">
                        <span class="sitename">Nama WEB</span>
                    </a>
                    <div class="footer-contact pt-3">
                        <?php if($instansi): ?>
                            <p><?php echo e($instansi); ?></p>
                        <?php endif; ?>
                        <?php if($alamat): ?>
                            <p class="mt-3"><strong>Alamat:</strong> <span><?php echo e($alamat); ?></span></p>
                        <?php endif; ?>
                        <?php if($nohp): ?>
                            <p class="mt-3"><strong>Phone:</strong> <span><?php echo e($nohp); ?></span></p>
                        <?php endif; ?>
                        <?php if($email): ?>
                            <p><strong>Email:</strong> <span><?php echo e($email); ?></span></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-3 footer-links">
                    <h4>Sosial Media</h4>
                    <div class="social-links d-flex mt-4">
                        <?php if($instansi): ?>
                            <a href="https://www.google.com/search?q=<?php echo e(str_replace(' ', '+', strtolower($instansi))); ?>&oq=smkn&gs_lcrp=EgZjaHJvbWUqBggAEEUYOzIGCAAQRRg7MgYIARBFGDkyBggCEEUYQDIGCAMQRRg8MgYIBBBFGDwyBggFEEUYPNIBCDEyNjFqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8"
                                target="_blank"><i class="bi bi-google"></i></a>
                        <?php endif; ?>
                        <?php if($twitter): ?>
                            <a href="https://www.x.com/<?php echo e($twitter); ?>" target="_blank"><i class="bi bi-twitter-x"></i></a>
                        <?php endif; ?>
                        <?php if($facebook): ?>
                            <a href="https://www.facebook.com/<?php echo e($facebook); ?>" target="_blank"><i class="bi bi-facebook"></i></a>
                        <?php endif; ?>
                        <?php if($instagram): ?>
                            <a href="https://www.instagram.com/<?php echo e($instagram); ?>" target="_blank"><i class="bi bi-instagram"></i></a>
                        <?php endif; ?>
                        <?php if($youtube): ?>
                            <a href="https://www.youtube.com/<?php echo e($youtube); ?>" target="_blank"><i class="bi bi-youtube"></i></a>
                        <?php endif; ?>
                        <?php if($tiktok): ?>
                            <a href="https://www.tiktok.com/&#64;<?php echo e($tiktok); ?>" target="_blank"><i class="bi bi-tiktok"></i></a>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    <?php endif; ?>

    <div class="container copyright text-center mt-4">
        &copy; 2024 <strong><span>NAMA WEB</span></strong>. Ver. 2024.1.1
    </div>

</footer>
<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/layouts/partial-guest/footer.blade.php ENDPATH**/ ?>