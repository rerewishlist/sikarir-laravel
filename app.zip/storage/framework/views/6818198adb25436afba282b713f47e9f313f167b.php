<?php $__env->startSection('title', 'Data Chat Siswa'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Data Chat Siswa</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Data Chat Siswa</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="card-title">Table Data Siswa</h5>
                                <!-- Form Pencarian -->
                                <form method="GET" action="<?php echo e(url('/admin/chat')); ?>" class="d-flex search-form">
                                    <input style="margin-right: 10px;" type="text" name="search" class="form-control"
                                        placeholder="Cari data nama siswa..." value="<?php echo e(request('search')); ?>">

                                    <!-- Dropdown untuk memilih kelas -->
                                    <select name="kelas" class="form-control" style="margin-right: 10px;">
                                        <option value="">Semua Kelas</option>
                                        <?php $__currentLoopData = $kelasOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kelas); ?>"
                                                <?php echo e(request('kelas') == $kelas ? 'selected' : ''); ?>><?php echo e($kelas); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <!-- Dropdown untuk memilih jurusan -->
                                    <select name="jurusan" class="form-control" style="margin-right: 10px;">
                                        <option value="">Semua Jurusan</option>
                                        <?php $__currentLoopData = $jurusanOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($jurusan->id); ?>"
                                                <?php echo e(request('jurusan') == $jurusan->id ? 'selected' : ''); ?>>
                                                <?php echo e($jurusan->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <button type="submit" class="btn btn-primary">Cari</button>
                                </form>
                                <!-- End Form Pencarian -->
                            </div>

                            <!-- Table with hoverable rows -->
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width: 1%" scope="col">No</th>
                                        <th style="width: 39%" scope="col">Nama</th>
                                        <th style="width: 35%" scope="col">Kelas Jurusan</th>
                                        <th style="width: 10%"scope="col">No HP</th>
                                        <th style="width: 15%" scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row">
                                                <?php echo e(($users->currentPage() - 1) * $users->perPage() + $loop->iteration); ?>

                                            </th>
                                            <td><?php echo e($item->nama); ?></td>
                                            <td><?php echo e($item->kelas); ?> <?php echo e($item->nama_jurusan); ?> <?php echo e($item->subkelas); ?></td>
                                            <td><?php echo e($item->nohp); ?></td>
                                            <td>
                                                <!-- Button Modal Edit Siswa-->
                                                <button type="button" class="btn btn-info" data-bs-toggle="modal"
                                                    data-bs-target="#detailModal<?php echo e($item->id); ?>">
                                                    <i class="bi bi-info-circle"></i>
                                                </button>
                                                <!-- End Button Modal Edit Siswa-->
                                                <!-- Button Chat-->
                                                <button type="button" class="btn btn-success"
                                                    onclick="window.location.href='<?php echo e(route('admin.chat.detail', $item->id)); ?>'">
                                                    <i class="bi bi-chat-dots"></i>
                                                </button>
                                                <!-- End Chat-->
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->

                        </div>
                    </div>
                </div>
            </div>

            <!-- Paginate -->
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <!-- Previous Page Link -->
                    <?php if($users->onFirstPage()): ?>
                        <li class="page-item disabled"><span class="page-link">Previous</span></li>
                    <?php else: ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($users->previousPageUrl()); ?>">Previous</a>
                        </li>
                    <?php endif; ?>

                    <!-- Pagination Elements -->
                    <?php for($i = 1; $i <= $users->lastPage(); $i++): ?>
                        <li class="page-item <?php echo e($i == $users->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($users->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>

                    <!-- Next Page Link -->
                    <?php if($users->hasMorePages()): ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($users->nextPageUrl()); ?>">Next</a></li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link">Next</span></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <!-- End Paginate -->
        </section>

    </main><!-- End #main -->

    <!-- Modal Edit Siswa-->
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="detailModal<?php echo e($item->id); ?>" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Data Detail Siswa</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="formEditSiswa<?php echo e($item->id); ?>" class="row g-3">
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input class="form-control" type="text" id="floatingNama" name="namaupdate"
                                        value="<?php echo e($item->nama); ?>" placeholder="Nama" disabled>
                                    <label for="floatingNama">Nama</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input class="form-control" type="text" id="floatingNis" name="nisupdate"
                                        value="<?php echo e($item->nis); ?>" placeholder="NIS" disabled>
                                    <label for="floatingNis">NIS</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input class="form-control" type="text" id="floatingNis" name="levelupdate"
                                        value="<?php echo e($item->level); ?>" placeholder="Level" disabled>
                                    <label for="floatingNis">Level</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input class="form-control" type="text" id="floatingNis" name="levelupdate"
                                        value="<?php echo e($item->kelas); ?> <?php echo e($item->nama_jurusan); ?> <?php echo e($item->subkelas); ?>"
                                        placeholder="Kelas Jurusan" disabled>
                                    <label for="floatingNis">Kelas Jurusan</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <input class="form-control" type="text" id="floatingNis"
                                        name="jenis_kelaminupdate" value="<?php echo e($item->jenis_kelamin); ?>"
                                        placeholder="Jenis Kelamin" disabled>
                                    <label for="floatingNis">Jenis Kelamin</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <div class="form-floating">
                                        <input class="form-control" type="text" id="floatingNis"
                                            name="tempat_lahirupdate" value="<?php echo e($item->tempat_lahir); ?>"
                                            placeholder="Jenis Kelamin" disabled>
                                        <label for="floatingNis">Tempat Lahir</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-floating">
                                    <div class="form-floating">
                                        <input class="form-control" type="text" id="floatingNis" name="tanggal_lahir"
                                            value="<?php echo e(date('d-m-Y', strtotime($item->tanggal_lahir))); ?>"
                                            placeholder="Jenis Kelamin" disabled>
                                        <label for="floatingNis">Tanggal Lahir</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <div class="form-floating">
                                        <input class="form-control" type="text" id="floatingNis" name="alamat"
                                            value="<?php echo e($item->alamat); ?>" placeholder="Alamat" disabled>
                                        <label for="floatingNis">Alamat</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <div class="form-floating">
                                        <input class="form-control" type="text" id="floatingNis" name="nohp"
                                            value="<?php echo e($item->nohp); ?>" placeholder="No HP" disabled>
                                        <label for="floatingNis">No HP</label>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- End Modal Edit Siswa-->

    <!-- Tambahkan JavaScript untuk menghapus parameter pencarian saat halaman di-refresh -->
    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('search');
            url.searchParams.delete('kelas');
            url.searchParams.delete('jurusan');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/chat/data-chat.blade.php ENDPATH**/ ?>