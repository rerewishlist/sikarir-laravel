<?php $__env->startSection('title', 'Chat'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle mb-5">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>
                <?php if($targetUser->foto): ?>
                    <img src="<?php echo e(asset('storage/foto/' . $targetUser->foto)); ?>" alt="Profile" class="rounded-circle"
                        style="width: 45px; height: 45px; object-fit: cover; border-radius: 50%; margin-right: 10px;">
                <?php endif; ?>
                <?php echo e($targetUser->nama); ?>

            </h1>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <?php
                        $currentUser = auth()->user();
                    ?>

                    <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($currentUser->level == 'admin'): ?>
                            <?php if($chat->from_admin_id == $currentUser->id): ?>
                                <div class="d-flex justify-content-end">
                                    <div class="card chat-hijau">
                                        <div class="card-body">
                                            <div class="content-justify mt-3" style="text-align: justify;">
                                                <?php if($chat->gambar): ?>
                                                    <img src="<?php echo e(asset('storage/chat/' . $chat->gambar)); ?>" alt="Image"
                                                        class="img-fluid mb-2"><br>
                                                <?php endif; ?>
                                                <?php echo e($chat->message); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="d-flex justify-content-start">
                                    <div class="card chat-abu">
                                        <div class="card-body">
                                            <div class="content-justify mt-3" style="text-align: justify;">
                                                <?php if($chat->gambar): ?>
                                                    <img src="<?php echo e(asset('storage/chat/' . $chat->gambar)); ?>" alt="Image"
                                                        class="img-fluid mb-2"><br>
                                                <?php endif; ?>
                                                <?php echo e($chat->message); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php elseif($currentUser->level == 'siswa'): ?>
                            <?php if($chat->from_user_id == $currentUser->id): ?>
                                <div class="d-flex justify-content-end">
                                    <div class="card chat-hijau">
                                        <div class="card-body">
                                            <div class="content-justify mt-3" style="text-align: justify;">
                                                <?php if($chat->gambar): ?>
                                                    <img src="<?php echo e(asset('storage/chat/' . $chat->gambar)); ?>" alt="Image"
                                                        class="img-fluid mb-2"><br>
                                                <?php endif; ?>
                                                <?php echo e($chat->message); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="d-flex justify-content-start">
                                    <div class="card chat-abu">
                                        <div class="card-body">
                                            <div class="content-justify mt-3" style="text-align: justify;">
                                                <?php if($chat->gambar): ?>
                                                    <img src="<?php echo e(asset('storage/chat/' . $chat->gambar)); ?>" alt="Image"
                                                        class="img-fluid mb-2"><br>
                                                <?php endif; ?>
                                                <?php echo e($chat->message); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <?php if(auth()->user()->level == 'admin'): ?>
                    <form action="<?php echo e(route('admin.chat.store', $targetUser->id)); ?>" method="post"
                        enctype="multipart/form-data" class="d-flex search-form w-100">
                    <?php elseif(auth()->user()->level == 'siswa'): ?>
                        <form action="<?php echo e(route('user.chat.store', $targetUser->id)); ?>" method="post"
                            enctype="multipart/form-data" class="d-flex search-form w-100">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <a class="btn btn-primary btn-sm" title="Upload gambar profile baru">
                    <i class="ri ri-attachment-line"></i>
                    <input type="file" class="form-control <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gambar"
                        id="formFileFoto" style="display: none;" placeholder="Foto"
                        onchange="this.nextElementSibling.textContent = this.files[0].name;">
                    <span></span>
                    <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback text-white">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </a>
                <input type="text" class="form-control ms-2 <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="message"
                    placeholder="Tulis pesan..." value="<?php echo e(old('body')); ?>">
                <button type="submit" class="btn btn-primary ms-2">Kirim</button>
                </form>
            </div>
        </div>
    </main><!-- End #main -->

    <style>
        .chat-hijau {
            background-color: #b2c0ff91;
            color: black;
            max-width: 60%;
            border-radius: 15px 15px 0 15px;
        }

        .chat-abu {
            background-color: #ffffff;
            color: black;
            max-width: 60%;
            border-radius: 15px 15px 15px 0;
        }
    </style>

    <script>
        document.querySelector('.btn').addEventListener('click', function() {
            document.getElementById('formFileFoto').click();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/chat/modal/detail.blade.php ENDPATH**/ ?>