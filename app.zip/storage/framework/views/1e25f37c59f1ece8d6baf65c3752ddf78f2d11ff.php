<section class="section">
    <div class="row">
        <div class="col-lg-12">

            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title">Table Data Materi</h5>
                        <!-- Form Pencarian -->
                        <form method="GET" action="<?php echo e(url('/admin/datamateri')); ?>" class="d-flex search-form">
                            <input style="margin-right: 10px;" type="text" name="search_materi" class="form-control"
                                placeholder="Cari judul materi..." value="<?php echo e(request('search_materi')); ?>">

                            <?php
                                $uniqueDates = collect($dates)
                                    ->map(function ($date) {
                                        return \Carbon\Carbon::parse($date)->format('Y-m');
                                    })
                                    ->unique();
                            ?>

                            <select name="filter_tanggal" class="form-control" style="margin-right: 10px;">
                                <option value="">-- Pilih Bulan dan Tahun --</option>
                                <?php $__currentLoopData = $uniqueDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($date); ?>" <?php echo e(request('filter_tanggal') == $date ? 'selected' : ''); ?>>
                                        <?php echo e(\Carbon\Carbon::parse($date)->format('F Y')); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <button type="submit" class="btn btn-primary">Cari</button>
                        </form>
                        <!-- End Form Pencarian -->
                    </div>

                    <!-- Button Modal Tambah materi-->
                    <a href="<?php echo e(route('datamateri.create')); ?>" class="btn btn-success mb-3">
                        <i class="bi bi-plus me-1"></i> Tambah Data
                    </a>
                    <!-- End button Modal Tambah materi -->

                    <!-- Table with hoverable rows -->
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th style="width: 1%" scope="col">No</th>
                                <th style="width: 40%" scope="col">Judul</th>
                                <th style="width: 19%" scope="col">Author</th>
                                <th style="width: 20%"scope="col">Tanggal</th>
                                <th style="width: 20%"scope="col">aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row">
                                        <?php echo e(($materis->currentPage() - 1) * $materis->perPage() + $loop->iteration); ?>

                                    </th>
                                    <td><?php echo e($item->judul); ?></td>
                                    <td><?php echo e($item->admin->nama); ?></td>
                                    <td><?php echo e($item->created_at->translatedFormat('d F Y')); ?></td>
                                    <td>
                                        <!-- Button Modal Edit Siswa-->
                                        <button type="button" class="btn btn-warning"
                                            onclick="window.location.href='<?php echo e(route('datamateri.edit', $item->id)); ?>'">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        <!-- End Button Modal Edit Siswa-->

                                        <!-- Button Chat-->
                                        <button type="button" class="btn btn-info"
                                            onclick="window.location.href='<?php echo e(route('datamateri.detail', $item->id)); ?>'">
                                            <i class="bi bi-info-circle"></i>
                                        </button>
                                        <!-- End Chat-->
                                        <!-- Button Modal Hapus Siswa-->
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                        <!-- End Button Modal Hapus Siswa-->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->

                </div>
            </div>
        </div>
    </div>

    <!-- Paginate -->
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <!-- Previous Page Link -->
            <?php if($materis->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link">Previous</span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($materis->previousPageUrl()); ?>">Previous</a>
                </li>
            <?php endif; ?>

            <!-- Pagination Elements -->
            <?php for($i = 1; $i <= $materis->lastPage(); $i++): ?>
                <li class="page-item <?php echo e($i == $materis->currentPage() ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($materis->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>

            <!-- Next Page Link -->
            <?php if($materis->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($materis->nextPageUrl()); ?>">Next</a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">Next</span></li>
            <?php endif; ?>
        </ul>
    </nav>
    <!-- End Paginate -->
</section>
<?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/materi/modal/table.blade.php ENDPATH**/ ?>