<?php $__env->startSection('title', 'Forum Page'); ?>
<?php $__env->startSection('menuForum', 'active'); ?>
<?php $__env->startSection('content-guest'); ?>

    <main class="main">

        <!-- Page Title -->
        <div class="page-title" data-aos="fade">
            <div class="container d-lg-flex justify-content-between align-items-center">
                <?php if(auth()->check()): ?>
                    <h1 class="mb-2 mb-lg-0">Forum Terbaru</h1>
                    <nav class="breadcrumbs">
                        <ol>
                            <li><a href="<?php echo e(Route('dashboard')); ?>">Home</a></li>
                            <li class="current">Forum</li>
                        </ol>
                    </nav>
                <?php else: ?>
                    <h1 class="mb-2 mb-lg-0">Forum Terpopuler</h1>
                    <nav class="breadcrumbs">
                        <ol>
                            <li><a href="<?php echo e(Route('landing')); ?>">Home</a></li>
                            <li class="current">Forum</li>
                        </ol>
                    </nav>
                <?php endif; ?>
            </div>
        </div><!-- End Page Title -->

        <!-- Service Details Section -->
        <section id="service-details" class="service-details section">

            <div class="container">
                <div class="row gy-5">
                    <?php if($forums->count() > 0): ?>
                        <?php if(auth()->check()): ?>
                            <div class="col-lg-3" data-aos="fade-up" data-aos-delay="100">
                                <div class="service-box">
                                    <div class="services-list text-center">
                                        <button onclick="window.location.href='<?php echo e(route('user.dataforum.create')); ?>'" class="btn btn-primary">
                                            <i class="bi bi-plus me-1"></i> Buat Forum Baru
                                        </button>
                                    </div>
                                </div><!-- End Services List -->

                                <div class="service-box">
                                    <div class="services-list">
                                        <form action="">
                                            <input type="text" name="search_forum" class="form-control mb-3" placeholder="Cari judul forum..."
                                                value="<?php echo e(request('search_forum')); ?>">
                                            <?php
                                                $uniqueDates = collect($dates)
                                                    ->map(function ($date) {
                                                        return \Carbon\Carbon::parse($date)->format('Y-m');
                                                    })
                                                    ->unique();
                                            ?>

                                            <select name="filter_tanggal" class="form-control" style="margin-right: 10px;">
                                                <option value="">-- Pilih Bulan dan Tahun --</option>
                                                <?php $__currentLoopData = $uniqueDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($date); ?>" <?php echo e(request('filter_tanggal') == $date ? 'selected' : ''); ?>>
                                                        <?php echo e(\Carbon\Carbon::parse($date)->format('F Y')); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button type="submit" class="btn btn-primary mt-3">Cari</button>
                                        </form>
                                    </div>
                                </div><!-- End Services List -->
                            </div>
                        <?php endif; ?>

                        <?php if(auth()->check()): ?>
                            <div class="col-lg-9 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
                            <?php else: ?>
                                <div class="col-lg-12 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
                        <?php endif; ?>

                        <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-5">
                                <h3><?php echo e($item->judul); ?></h3>
                                <?php if($item->gambar): ?>
                                    <img src="<?php echo e(asset('storage/forum/' . $item->gambar)); ?>" alt="Gambar forum" class="img-fluid services-img">
                                <?php endif; ?>
                                <p>
                                    <?php if($item->admin): ?>
                                        by <?php echo e($item->admin->level); ?> |
                                    <?php else: ?>
                                        by <?php echo e($item->user->level); ?> |
                                    <?php endif; ?>
                                    <?php echo e($item->created_at->translatedFormat('d F Y')); ?> |
                                    <?php echo e($item->comments->count()); ?> balasan
                                </p>
                                <p>
                                    <?php echo \Illuminate\Support\Str::limit(strip_tags($item->content), 300, '...'); ?>

                                </p>
                                <?php if(auth()->check()): ?>
                                    <a href="<?php echo e(Route('user.dataforum.detail', $item->id)); ?>">Selengkapnya...</a>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if(auth()->check()): ?>
                            <!-- Paginate -->
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <!-- Previous Page Link -->
                                    <?php if($forums->onFirstPage()): ?>
                                        <li class="page-item disabled"><span class="page-link">Previous</span></li>
                                    <?php else: ?>
                                        <li class="page-item"><a class="page-link" href="<?php echo e($forums->previousPageUrl()); ?>">Previous</a>
                                        </li>
                                    <?php endif; ?>

                                    <!-- Pagination Elements -->
                                    <?php for($i = 1; $i <= $forums->lastPage(); $i++): ?>
                                        <li class="page-item <?php echo e($i == $forums->currentPage() ? 'active' : ''); ?>">
                                            <a class="page-link" href="<?php echo e($forums->url($i)); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>

                                    <!-- Next Page Link -->
                                    <?php if($forums->hasMorePages()): ?>
                                        <li class="page-item"><a class="page-link" href="<?php echo e($forums->nextPageUrl()); ?>">Next</a></li>
                                    <?php else: ?>
                                        <li class="page-item disabled"><span class="page-link">Next</span></li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                            <!-- End Paginate -->
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="col-lg-9 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
                            <div class="mb-5">
                                <h3>Belum ada forum</h3>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            </div>

            </div>


        </section><!-- /Service Details Section -->

    </main>

    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('search_forum');
            url.searchParams.delete('filter_tanggal');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/menu-forum.blade.php ENDPATH**/ ?>