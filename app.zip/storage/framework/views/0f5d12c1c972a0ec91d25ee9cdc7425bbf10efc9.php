<?php $__env->startSection('title', 'Forum Page Detail'); ?>
<?php $__env->startSection('menuForum', 'active'); ?>
<?php $__env->startSection('content-guest'); ?>

    <main class="main">

        <!-- Page Title -->
        <div class="page-title" data-aos="fade">
            <div class="container d-lg-flex justify-content-between align-items-center">
                <div class="mb-2 mb-lg-0">
                    <h1><?php echo e($forum->judul); ?></h1>
                    <?php if($forum->admin): ?>
                        by <?php echo e($forum->admin->nama); ?> (<?php echo e($forum->admin->level); ?>) |
                    <?php elseif($forum->user): ?>
                        by <?php echo e($forum->user->nama); ?> (<?php echo e($forum->user->level); ?>) |
                    <?php else: ?>
                        <!-- Anda bisa menampilkan pesan atau elemen lain jika admin dan user tidak ada -->
                        <span>Admin dan User tidak tersedia</span>
                    <?php endif; ?>
                    <?php echo e($forum->created_at->translatedFormat('d F Y')); ?>

                </div>

                <nav class="breadcrumbs">
                    <ol>
                        <li><a href="<?php echo e(Route('dashboard')); ?>">Home</a></li>
                        <li><a href="<?php echo e(Route('user.dataforum.view')); ?>">Forum</a></li>
                        <li class="current">Detail Forum</li>
                    </ol>
                </nav>
            </div>
        </div><!-- End Page Title -->

        <!-- Service Details Section -->
        <section id="service-details" class="service-details section">
            <div class="container">
                <div class="row gy-5">
                    <div class="col-lg-10 ps-lg-5" data-aos="fade-up" data-aos-delay="100">
                        <?php if($forum->gambar): ?>
                            <img src="<?php echo e(asset('storage/forum/' . $forum->gambar)); ?>" alt="Gambar berita" class="img-fluid services-img">
                        <?php endif; ?>
                        <div class="content-justify" style="text-align: justify;">
                            <?php echo $forum->content; ?>

                        </div>
                        <form action="<?php echo e(route('user.datacomment.store', $forum->id)); ?>" method="POST" class="d-flex search-form w-100">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="forum_id" value="<?php echo e($forum->id); ?>">
                            <input type="text" class="form-control <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> flex-grow-1" name="body" id="inputText"
                                placeholder="Tulis Komentar" value="<?php echo e(old('body')); ?>">
                            <button type="submit" class="btn btn-primary ms-2">Kirim</button>
                        </form>
                    </div>

                    <div class="col-lg-10 ps-lg-5" data-aos="fade-up" data-aos-delay="100">
                        <h3>Komentar</h3>
                        <hr>
                        <?php if($forum->comments->count() > 0): ?>
                            <?php $__currentLoopData = $forum->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex align-items-center mb-2">
                                    <?php if(($comment->admin && $comment->admin->foto) || ($comment->user && $comment->user->foto)): ?>
                                        <img src="<?php echo e($comment->admin && $comment->admin->foto ? asset('storage/foto/' . $comment->admin->foto) : asset('storage/foto/' . $comment->user->foto)); ?>"
                                            alt="Profile" class="rounded-circle"
                                            style="width: 30px; height: 30px; object-fit: cover; border-radius: 50%; margin-right: 10px;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/img/blank-profile-picture.jpg')); ?>" alt="Profile" class="rounded-circle"
                                            style="width: 30px; height: 30px; object-fit: cover; border-radius: 50%; margin-right: 10px;">
                                    <?php endif; ?>
                                    <div class="d-flex flex-column">
                                        <span style="font-size: 0.8em; color: gray;">
                                            <b>
                                                <?php if($comment->admin): ?>
                                                    <?php echo e($comment->admin->nama); ?> (<?php echo e($comment->admin->level); ?>)
                                                <?php elseif($comment->user): ?>
                                                    <?php echo e($comment->user->nama); ?> (<?php echo e($comment->user->level); ?>)
                                                <?php else: ?>
                                                    Admin dan User tidak tersedia
                                                <?php endif; ?>
                                            </b>
                                            , <?php echo e($comment->created_at->translatedFormat('j F Y, H:i A')); ?>

                                        </span>
                                    </div>
                                </div>

                                <p class="content-justify" style="text-align: justify;">
                                    <?php echo e($comment->body); ?>

                                </p>
                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="d-flex align-items-center mb-2">
                                Belum Ada Komentar
                            </div>
                            <hr>
                        <?php endif; ?>
                    </div><!-- End Card with header and footer -->

                </div>
            </div>
        </section><!-- /Service Details Section -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/forum/modal/detail-siswa.blade.php ENDPATH**/ ?>