<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startSection('menuLanding', 'active'); ?>
<?php $__env->startSection('content-guest'); ?>

    <main class="main">

        <!-- Hero Section -->
        <section id="hero" class="hero section">
            <div class="hero-bg">
                <?php
                    $videoyt = optional($informasi)->videoyt;
                    // Ekstrak ID video dari URL YouTube
                    preg_match('/v=([a-zA-Z0-9_-]{11})/', $videoyt, $matches);
                    $videoId = $matches[1] ?? null;
                ?>
                <?php if($videoyt): ?>
                    <iframe width="100%" height="100%"
                        src="https://www.youtube.com/embed/<?php echo e($videoId); ?>?autoplay=1&mute=1&controls=0&modestbranding=1&rel=0&si=wEFeD_OyUlxlaYHW"
                        title="YouTube video player" frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                <?php endif; ?>
            </div>

            <div class="container text-center">
                <div class="d-flex flex-column justify-content-center align-items-center">
                    <h1 data-aos="fade-up">Welcome to <span>Nama Web</span></h1>
                    <p data-aos="fade-up" data-aos-delay="100">Quickly start your project now and set the stage for success<br></p>
                    
                </div>
            </div>
        </section><!-- /Hero Section -->

        <!-- Featured Services Section -->
        <section id="featured-services" class="featured-services section light-background">

            <div class="container">

                <div class="row gy-4" style="display: flex; justify-content: center; flex-wrap: wrap;">

                    <div class="col-xl-2 col-lg-6" data-aos="fade-up" data-aos-delay="100">
                        <div class="service-item d-flex">
                            <div class="icon flex-shrink-0"><i class="bi bi-briefcase"></i></div>
                            <div>
                                <h4 class="title"><a href="#" class="stretched-link"><span class="count-jurusan"
                                            style="font-size: 40px;">0</span></a></h4>
                                <p class="description">Jurusan</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-lg-6" data-aos="fade-up" data-aos-delay="200">
                        <div class="service-item d-flex">
                            <div class="icon flex-shrink-0"><i class="bi bi-people"></i></div>
                            <div>
                                <h4 class="title"><a href="#" class="stretched-link"><span class="count-siswa"
                                            style="font-size: 40px;">0</span></a></h4>
                                <p class="description">Siswa</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-lg-6" data-aos="fade-up" data-aos-delay="300">
                        <div class="service-item d-flex">
                            <div class="icon flex-shrink-0"><i class="bi bi-newspaper"></i></div>
                            <div>
                                <h4 class="title"><a href="#" class="stretched-link"><span class="count-berita"
                                            style="font-size: 40px;">0</span></a></h4>
                                <p class="description">Berita</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-lg-6" data-aos="fade-up" data-aos-delay="400">
                        <div class="service-item d-flex">
                            <div class="icon flex-shrink-0"><i class="ri ri-discuss-line"></i></div>
                            <div>
                                <h4 class="title"><a href="#" class="stretched-link"><span class="count-forum"
                                            style="font-size: 40px;">0</span></a></h4>
                                <p class="description">Forum</p>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </section><!-- /Featured Services Section -->

        <!-- Features Section -->
        <section id="features" class="features section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>Berita Terbaru</h2>
                <p></p>
            </div><!-- End Section Title -->

            <div class="container">
                <div class="row justify-content-between">

                    <div class="col-lg-5 d-flex align-items-center">
                        <ul class="nav nav-tabs" data-aos="fade-up" data-aos-delay="100">
                            <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item">
                                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#features-tab-<?php echo e($item->id); ?>"
                                        href="#features-tab-<?php echo e($item->id); ?>" onclick="activateTab(event, '<?php echo e($item->id); ?>')">
                                        <i class="bi bi-binoculars"></i>
                                        <div>
                                            <h4 class="d-none d-lg-block"><?php echo e($item->judul); ?></h4>
                                            <p>
                                                <?php echo \Illuminate\Support\Str::limit(strip_tags($item->content), 200, '...'); ?>

                                            </p>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul><!-- End Tab Nav -->
                    </div>

                    <div class="col-lg-6">
                        <div class="tab-content" data-aos="fade-up" data-aos-delay="200">
                            <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade" id="features-tab-<?php echo e($item->id); ?>">
                                    <a href="<?php echo e(Route('berita.detail.menu', $item->slug)); ?>">

                                        <?php
                                            $randomImages = [
                                                'assets/img/berita1.jpeg',
                                                'assets/img/berita2.jpeg',
                                                'assets/img/berita3.jpeg',
                                                'assets/img/berita4.jpeg',
                                                'assets/img/berita5.jpeg',
                                            ];
                                            $randomImage = $randomImages[array_rand($randomImages)];
                                        ?>
                                        <?php if($item->gambar): ?>
                                            <img src="<?php echo e(asset('storage/berita/' . $item->gambar)); ?>" alt="" class="img-fluid"
                                                style="width: 700px; height: 700px; object-fit: cover;">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset($randomImage)); ?>" alt="" class="img-fluid"
                                                style="width: 700px; height: 700px; object-fit: cover;">
                                        <?php endif; ?>
                                    </a>
                                </div><!-- End Tab Content Item -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
            </div>

        </section><!-- /Features Section -->

    </main>

    <script>
        $(document).ready(function() {
            // Fungsi untuk animasi penghitung
            function animateCounter(selector, endValue, duration) {
                var $element = $(selector);
                $element.text(0); // Inisialisasi teks awal

                $({
                    count: 0
                }).animate({
                    count: endValue
                }, {
                    duration: duration,
                    easing: 'swing',
                    step: function() {
                        $element.text(Math.ceil(this.count));
                    }
                });
            }

            // Panggil fungsi animasi penghitung untuk totalBerita dan totalSiswa
            var totalJurusan = <?php echo e($totalJurusan); ?>;
            var totalSiswa = <?php echo e($totalSiswa); ?>;
            var totalBerita = <?php echo e($totalBerita); ?>;
            var totalForum = <?php echo e($totalForum); ?>;

            if (!isNaN(totalJurusan) && totalJurusan > 0) {
                animateCounter('.count-jurusan', totalJurusan, 3000); // 2000 ms atau 2 detik
            }

            if (!isNaN(totalSiswa) && totalSiswa > 0) {
                animateCounter('.count-siswa', totalSiswa, 3000); // 2000 ms atau 2 detik
            }

            if (!isNaN(totalBerita) && totalBerita > 0) {
                animateCounter('.count-berita', totalBerita, 3000); // 2000 ms atau 2 detik
            }

            if (!isNaN(totalForum) && totalForum > 0) {
                animateCounter('.count-forum', totalForum, 3000); // 2000 ms atau 2 detik
            }
        });
    </script>

    <script>
        function activateTab(event, id) {
            // Prevent the default anchor click behavior
            event.preventDefault();

            // Remove 'active show' classes from all nav links and tab panes
            document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active', 'show'));
            document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active', 'show'));

            // Add 'active show' classes to the clicked tab and its corresponding tab pane
            event.currentTarget.classList.add('active', 'show');
            document.querySelector(`#features-tab-${id}`).classList.add('active', 'show');
        }

        // Automatically activate the first tab on page load
        document.addEventListener('DOMContentLoaded', () => {
            const firstTabLink = document.querySelector('.nav-link');
            if (firstTabLink) {
                firstTabLink.classList.add('active', 'show');
                const firstTabPaneId = firstTabLink.getAttribute('data-bs-target');
                document.querySelector(firstTabPaneId).classList.add('active', 'show');
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/welcome.blade.php ENDPATH**/ ?>