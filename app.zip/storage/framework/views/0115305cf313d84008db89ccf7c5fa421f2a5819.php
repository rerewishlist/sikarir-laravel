<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title">Table Data Forum Diskusi</h5>
                        <!-- Form Pencarian -->
                        <form method="GET" action="<?php echo e(url('/siswa/forumdiskusi')); ?>" class="d-flex search-form">
                            <input style="margin-right: 10px;" type="text" name="search_forum" class="form-control" placeholder="Cari data foru..."
                                value="<?php echo e(request('search_forum')); ?>">
                            <?php
                                $uniqueDates = collect($dates)
                                    ->map(function ($date) {
                                        return \Carbon\Carbon::parse($date)->format('Y-m');
                                    })
                                    ->unique();
                            ?>

                            <select name="filter_tanggal" class="form-control" style="margin-right: 10px;">
                                <option value="">-- Pilih Bulan dan Tahun --</option>
                                <?php $__currentLoopData = $uniqueDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($date); ?>" <?php echo e(request('filter_tanggal') == $date ? 'selected' : ''); ?>>
                                        <?php echo e(\Carbon\Carbon::parse($date)->format('F Y')); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-primary">Cari</button>
                        </form>
                        <!-- End Form Pencarian -->
                    </div>
                    <!-- Button Modal Tambah Forum-->
                    <a href="<?php echo e(route('user.dataforum.create')); ?>" class="btn btn-primary mb-3">
                        <i class="bi bi-plus me-1"></i> Buat Forum
                    </a>
                    <!-- End button Modal Tambah Forum -->
                </div>
            </div>

            <?php if($forums->count() > 0): ?>
                <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <?php if($item->gambar): ?>
                            <img src="<?php echo e(asset('storage/forum/' . $item->gambar)); ?>" alt="foto" class="card-img-top"
                                style="height: 300px; object-fit: cover;">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item->judul); ?></h5>
                            <p class="card-text"><?php echo \Illuminate\Support\Str::limit(strip_tags($item->content), 400, '...'); ?></p>
                            <a href="<?php echo e(route('user.dataforum.detail', $item->id)); ?>" class="btn btn-primary">Selengkapnya...</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <p class="card-text mt-4">Tidak ada forum</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>

    <!-- Paginate -->
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <!-- Previous Page Link -->
            <?php if($forums->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link">Previous</span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($forums->previousPageUrl()); ?>">Previous</a>
                </li>
            <?php endif; ?>

            <!-- Pagination Elements -->
            <?php for($i = 1; $i <= $forums->lastPage(); $i++): ?>
                <li class="page-item <?php echo e($i == $forums->currentPage() ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($forums->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>

            <!-- Next Page Link -->
            <?php if($forums->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($forums->nextPageUrl()); ?>">Next</a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">Next</span></li>
            <?php endif; ?>
        </ul>
    </nav>
    <!-- End Paginate -->
</section>
<?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/forum/forum-siswa.blade.php ENDPATH**/ ?>