<!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
        <a href="index.html" class="logo d-flex align-items-center">
            <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="">
            <span class="d-none d-lg-block">WEB</span>
        </a>
        <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->


    <nav class="header-nav ms-auto">
        <ul class="d-flex align-items-center">

            <li class="nav-item d-block d-lg-none">
                <a class="nav-link nav-icon search-bar-toggle " href="#">
                    <i class="bi bi-search"></i>
                </a>
            </li><!-- End Search Icon-->

            <li class="nav-item dropdown">
                <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-bell"></i>
                    <?php if($beritaforumNotifications->count() > 0): ?>
                        <span class="badge bg-primary badge-number">!</span>
                    <?php endif; ?>
                </a><!-- End Notification Icon -->
                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                    <li class="dropdown-header">
                        Anda memiliki <?php echo e($beritaforumNotifications->count()); ?> notifikasi baru
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <?php $__currentLoopData = $beritaforumNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="notification-item">
                            <?php if(auth()->user()->level == 'admin'): ?>
                                <?php if($item->data['type'] == 'berita'): ?>
                                    <i class="bi bi-newspaper text-primary"></i>
                                    <a href="<?php echo e(route('databerita.detail', $item->data['berita_id'])); ?>">
                                    <?php elseif($item->data['type'] == 'forum'): ?>
                                        <i class="bi bi-chat-dots text-info"></i>
                                        <a href="<?php echo e(route('admin.dataforum.detail', $item->data['forum_id'])); ?>">
                                <?php endif; ?>
                            <?php elseif(auth()->user()->level == 'siswa'): ?>
                                <?php if($item->data['type'] == 'berita'): ?>
                                    <i class="bi bi-newspaper text-primary"></i>
                                    <a href="<?php echo e(route('user.berita.detail', $item->data['berita_id'])); ?>">
                                    <?php elseif($item->data['type'] == 'forum'): ?>
                                        <i class="bi bi-chat-dots text-info"></i>
                                        <a href="<?php echo e(route('user.dataforum.detail', $item->data['forum_id'])); ?>">
                                <?php endif; ?>
                            <?php endif; ?>
                            <div>
                                <h4><?php echo \Illuminate\Support\Str::limit(strip_tags($item->data['judul']), 20, '...'); ?></h4>
                                <p><?php echo \Illuminate\Support\Str::limit(strip_tags($item->data['content']), 20, '...'); ?></p>
                                <p><?php echo e($item->created_at->diffForHumans()); ?></p>
                            </div>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(auth()->user()->level == 'admin'): ?>
                        <li class="dropdown-footer">
                            <a href="<?php echo e(route('admin.notifications.view')); ?>">Tampilkan semua notifikasi</a>
                        </li>
                    <?php elseif(auth()->user()->level == 'siswa'): ?>
                        <li class="dropdown-footer">
                            <a href="<?php echo e(route('user.notifications.view')); ?>">Tampilkan semua notifikasi</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li><!-- End Notification Nav -->

            <li class="nav-item dropdown">
                <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-chat-left-text"></i>
                    <?php if($chatNotifications->whereNull('read_at')->count() > 0): ?>
                        <span class="badge bg-success badge-number"><?php echo e($chatNotifications->whereNull('read_at')->count()); ?></span>
                    <?php endif; ?>
                </a><!-- End Messages Icon -->
                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
                    <li class="dropdown-header">
                        Anda memiliki <?php echo e($chatNotifications->whereNull('read_at')->count()); ?> pesan belum terbaca
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <?php $__currentLoopData = $chatNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->read_at === null): ?>
                            <!-- Menampilkan hanya notifikasi yang belum dibaca -->
                            <li class="message-item">
                                <?php
                                    $fromId = $item->data['from_id'];
                                    $user = \App\Models\User::find($fromId);
                                    $admin = \App\Models\Admin::find($fromId);

                                    $fromAdminPhoto = $admin->foto;
                                    $fromUserPhoto = $user->foto;
                                ?>

                                <?php if(auth()->user()->level == 'admin'): ?>
                                    <a href="<?php echo e(route('admin.chat.detail', $item->data['from_id'])); ?>">
                                        <?php if($fromUserPhoto): ?>
                                            <img src="<?php echo e(asset('storage/foto/' . $fromUserPhoto)); ?>" alt="" class="rounded-circle"
                                                style="width: 37px; height: 37px; object-fit: cover;">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/img/blank-profile-picture.jpg')); ?>" alt="" class="rounded-circle"
                                                style="width: 37px; height: 37px; object-fit: cover;">
                                        <?php endif; ?>
                                    <?php elseif(auth()->user()->level == 'siswa'): ?>
                                        <a href="<?php echo e(route('user.chat.detail', $item->data['from_id'])); ?>">
                                            <?php if($fromAdminPhoto): ?>
                                                <img src="<?php echo e(asset('storage/foto/' . $fromAdminPhoto)); ?>" alt="" class="rounded-circle"
                                                    style="width: 37px; height: 37px; object-fit: cover;">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/img/blank-profile-picture.jpg')); ?>" alt="" class="rounded-circle"
                                                    style="width: 37px; height: 37px; object-fit: cover;">
                                            <?php endif; ?>
                                <?php endif; ?>
                                <div>
                                    <h4><?php echo e($item->data['from_name']); ?></h4>
                                    <p><?php echo e($item->data['message']); ?></p>
                                    <p><?php echo e($item->created_at->diffForHumans()); ?></p>
                                </div>
                                </a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="dropdown-footer">
                    </li>
                </ul><!-- End Messages Dropdown Items -->
            </li><!-- End Messages Nav -->

            <li class="nav-item dropdown pe-3">

                <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                    <?php if($currentUser->foto): ?>
                        <img src="<?php echo e(asset('storage/foto/' . $currentUser->foto)); ?>" alt="Profile" class="rounded-circle"
                            style="width: 37px; height: 37px; object-fit: cover; border-radius: 50%;">
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/img/blank-profile-picture.jpg')); ?>" alt="Profile" class="rounded-circle"
                            style="width: 37px; height: 37px; object-fit: cover; border-radius: 50%;">
                    <?php endif; ?>
                    <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo e($currentUser->nama); ?></span>
                </a><!-- End Profile Iamge Icon -->

                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                    <li class="dropdown-header">
                        <h6><?php echo e($currentUser->nama); ?></h6>
                        <span><?php echo e($currentUser->level); ?></span>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>

                    <?php if(auth()->user()->level == 'admin'): ?>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('profile.admin.edit')); ?>">
                                <i class="bi bi-person"></i>
                                <span>My Profile</span>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <form id="logout-form" action="<?php echo e(url('admin/logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <a class="dropdown-item d-flex align-items-center" href="#"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Sign Out</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if(auth()->user()->level == 'siswa'): ?>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('profile.edit')); ?>">
                                <i class="bi bi-person"></i>
                                <span>My Profile</span>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <a class="dropdown-item d-flex align-items-center" href="#"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Sign Out</span>
                            </a>
                        </li>
                    <?php endif; ?>



                </ul><!-- End Profile Dropdown Items -->
            </li><!-- End Profile Nav -->

        </ul>
    </nav><!-- End Icons Navigation -->

</header><!-- End Header -->
<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/layouts/partial/header.blade.php ENDPATH**/ ?>