<h2>Student dashboard</h2>
<form id="logout-form" action="<?php echo e(url('student/logout')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
</form>
<a class="dropdown-item d-flex align-items-center" href="#"
    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
    <i class="bi bi-box-arrow-right"></i>
    <span>log Out</span>
</a>
<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/student/layouts/student-dashboard.blade.php ENDPATH**/ ?>