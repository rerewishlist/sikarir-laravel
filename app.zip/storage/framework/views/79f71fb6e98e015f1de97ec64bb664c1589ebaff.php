<?php $__env->startSection('title', 'Berita Page'); ?>
<?php $__env->startSection('menuBerita', 'active'); ?>
<?php $__env->startSection('content-guest'); ?>

    <main class="main">

        <!-- Page Title -->
        <div class="page-title" data-aos="fade">
            <div class="container d-lg-flex justify-content-between align-items-center">
                <div class="mb-2 mb-lg-0">
                    <h1><?php echo e($berita->judul); ?></h1>
                    by <?php echo e($berita->admin->nama); ?> |
                    <?php echo e($berita->created_at->translatedFormat('d F Y')); ?> |
                    <?php $__currentLoopData = $berita->kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><?php echo e($kategori->nama); ?><?php echo e($loop->last ? '' : ' |'); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <nav class="breadcrumbs">
                    <ol>
                        <?php if(auth()->check()): ?>
                            <li><a href="<?php echo e(Route('dashboard')); ?>">Home</a></li>
                            <li><a href="<?php echo e(Route('user.berita.view')); ?>">Berita</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(Route('landing')); ?>">Home</a></li>
                            <li><a href="<?php echo e(Route('berita.menu')); ?>">Berita</a></li>
                        <?php endif; ?>
                        <li class="current"><?php echo e($berita->judul); ?></li>
                    </ol>
                </nav>
            </div>
        </div><!-- End Page Title -->

        <!-- Service Details Section -->
        <section id="service-details" class="service-details section">

            <div class="container">

                <div class="row gy-5">
                    <div class="col-lg-10 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
                        <?php if($berita->gambar): ?>
                            <img src="<?php echo e(asset('storage/berita/' . $berita->gambar)); ?>" alt="Gambar berita" class="img-fluid services-img mb-5">
                        <?php endif; ?>
                        <div class="content-justify" style="text-align: justify;">
                            <?php echo $berita->content; ?>

                        </div>

                    </div>

                </div>

            </div>

        </section><!-- /Service Details Section -->

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/menu-berita-detail.blade.php ENDPATH**/ ?>