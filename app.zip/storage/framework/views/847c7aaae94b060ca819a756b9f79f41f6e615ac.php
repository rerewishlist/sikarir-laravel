<?php $__env->startSection('title', 'Data Berita'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Data Berita</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Data Berita</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="card-title">Table Data Berita</h5>
                                <!-- Form Pencarian -->
                                <form method="GET" action="<?php echo e(url('/admin/databerita')); ?>" class="d-flex search-form">
                                    <input style="margin-right: 10px;" type="text" name="search_berita" class="form-control"
                                        placeholder="Cari judul berita..." value="<?php echo e(request('search_berita')); ?>">

                                    <?php
                                        $uniqueDates = collect($dates)
                                            ->map(function ($date) {
                                                return \Carbon\Carbon::parse($date)->format('Y-m');
                                            })
                                            ->unique();
                                    ?>

                                    <select name="filter_tanggal" class="form-control" style="margin-right: 10px;">
                                        <option value="">-- Pilih Bulan dan Tahun --</option>
                                        <?php $__currentLoopData = $uniqueDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($date); ?>" <?php echo e(request('filter_tanggal') == $date ? 'selected' : ''); ?>>
                                                <?php echo e(\Carbon\Carbon::parse($date)->format('F Y')); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <!-- Dropdown untuk memilih kategori -->
                                    <select name="filter_kategori" class="form-control" style="margin-right: 10px;">
                                        <option value="">-- Pilih Kategori --</option>
                                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kategori->id); ?>" <?php echo e(request('filter_kategori') == $kategori->id ? 'selected' : ''); ?>>
                                                <?php echo e($kategori->nama); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit" class="btn btn-primary">Cari</button>
                                </form>
                                <!-- End Form Pencarian -->
                            </div>

                            <!-- Button Modal Tambah Berita-->
                            <a href="<?php echo e(route('databerita.create')); ?>" class="btn btn-primary mb-3">
                                <i class="bi bi-plus me-1"></i> Tambah Data
                            </a>
                            <!-- End button Modal Tambah Berita -->

                            <!-- Table with hoverable rows -->
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width: 1%" scope="col">No</th>
                                        <th style="width: 20%" scope="col">Judul</th>
                                        <th style="width: 15%" scope="col">Author</th>
                                        <th style="width: 15%" scope="col">Slug</th>
                                        <th style="width: 19%" scope="col">Kategori</th>
                                        <th style="width: 10%"scope="col">Tanggal</th>
                                        <th style="width: 20%"scope="col">aksi</th>
                                    </tr>
                                </thead>
                                <?php if($beritas->count() > 0): ?>
                                    <tbody>
                                        <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row">
                                                    <?php echo e(($beritas->currentPage() - 1) * $beritas->perPage() + $loop->iteration); ?>

                                                </th>
                                                <td><?php echo e($item->judul); ?></td>
                                                <td><?php echo e($item->admin->username); ?></td>
                                                <td><?php echo e($item->slug); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $item->kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge bg-primary"><?php echo e($kategori->nama); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td><?php echo e($item->created_at->translatedFormat('d F Y')); ?></td>
                                                <td>
                                                    <!-- Button Chat-->
                                                    <button type="button" class="btn btn-outline-info"
                                                        onclick="window.location.href='<?php echo e(route('databerita.detail', $item->id)); ?>'">
                                                        <i class="bi bi-info-circle"></i>
                                                    </button>
                                                    <!-- End Chat-->

                                                    <!-- Button Modal Edit Siswa-->
                                                    <button type="button" class="btn btn-outline-warning"
                                                        onclick="window.location.href='<?php echo e(route('databerita.edit', $item->id)); ?>'">
                                                        <i class="bi bi-pencil-square"></i>
                                                    </button>
                                                    <!-- End Button Modal Edit Siswa-->

                                                    <!-- Button Modal Hapus Siswa-->
                                                    <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal"
                                                        data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                    <!-- End Button Modal Hapus Siswa-->

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                <?php else: ?>
                                    <tbody>
                                        <tr>
                                            <td colspan="7" class="text-center align-middle">
                                                Tidak ada data berita
                                            <td>
                                        </tr>
                                    </tbody>
                                <?php endif; ?>
                            </table>
                            <!-- End Table with stripped rows -->

                        </div>
                    </div>
                </div>
            </div>

            <!-- Paginate -->
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <!-- Previous Page Link -->
                    <?php if($beritas->onFirstPage()): ?>
                        <li class="page-item disabled"><span class="page-link">Previous</span></li>
                    <?php else: ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($beritas->previousPageUrl()); ?>">Previous</a>
                        </li>
                    <?php endif; ?>

                    <!-- Pagination Elements -->
                    <?php for($i = 1; $i <= $beritas->lastPage(); $i++): ?>
                        <li class="page-item <?php echo e($i == $beritas->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($beritas->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>

                    <!-- Next Page Link -->
                    <?php if($beritas->hasMorePages()): ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($beritas->nextPageUrl()); ?>">Next</a></li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link">Next</span></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <!-- End Paginate -->
        </section>


        <?php echo $__env->make('berita.modal.hapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    </main><!-- End #main -->

    <!-- Tambahkan JavaScript untuk menghapus parameter pencarian saat halaman di-refresh -->
    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('search_berita');
            url.searchParams.delete('filter_tanggal');
            url.searchParams.delete('filter_kategori');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/berita/data-berita.blade.php ENDPATH**/ ?>