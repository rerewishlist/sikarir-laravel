<?php $__env->startSection('title', 'Detail Forum'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Detail Forum</h1>
            <nav>
                <ol class="breadcrumb">
                    <?php if(auth()->user()->level == 'admin'): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dataforum.view')); ?>">Data Forum Diskusi</a></li>
                    <?php elseif(auth()->user()->level == 'siswa'): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('user.dataforum.view')); ?>">Data Forum Diskusi</a></li>
                    <?php endif; ?>
                    <li class="breadcrumb-item active">Detail Forum <?php echo e($forum->judul); ?></li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Card with header and footer -->
                    <div class="card mb-3">
                        <div class="card-header">
                            <div class="d-flex align-items-start">
                                <?php if(($forum->admin && $forum->admin->foto) || ($forum->user && $forum->user->foto)): ?>
                                    <img src="<?php echo e($forum->admin && $forum->admin->foto ? asset('storage/foto/' . $forum->admin->foto) : asset('storage/foto/' . $forum->user->foto)); ?>"
                                        alt="Profile" class="rounded-circle"
                                        style="width: 45px; height: 45px; object-fit: cover; border-radius: 50%; margin-right: 10px;">
                                <?php endif; ?>
                                <div class="d-flex flex-column">
                                    <?php if($forum->admin): ?>
                                        <span><?php echo e($forum->admin->nama); ?> (<?php echo e($forum->admin->level); ?>)</span>
                                    <?php elseif($forum->user): ?>
                                        <span><?php echo e($forum->user->nama); ?> (<?php echo e($forum->user->level); ?>)</span>
                                    <?php else: ?>
                                        <!-- Anda bisa menampilkan pesan atau elemen lain jika admin dan user tidak ada -->
                                        <span>Admin dan User tidak tersedia</span>
                                    <?php endif; ?>
                                    <span style="font-size: 1.0em; color: gray;">
                                        <?php echo e($forum->created_at->translatedFormat('l, j F Y, H:i A')); ?>

                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <h5 class="card-title" style="font-size: 30px;"><?php echo e($forum->judul); ?></h5>
                            <?php if($forum->gambar): ?>
                                <img src="<?php echo e(asset('storage/forum/' . $forum->gambar)); ?>" alt="Gambar forum"
                                    class="img-thumbnail mb-4"
                                    style="max-width: 500px; max-height: 500px; object-fit: cover;">
                            <?php endif; ?>
                            <div class="content-justify" style="text-align: justify;">
                                <?php echo $forum->content; ?>

                            </div>
                        </div>

                        <div class="card-footer">
                            <div class="d-flex justify-content-between align-items-center">
                                <?php if(auth()->user()->level == 'admin'): ?>
                                    <form action="<?php echo e(route('admin.datacomment.store', $forum->id)); ?>" method="POST"
                                        class="d-flex search-form w-100">
                                    <?php elseif(auth()->user()->level == 'siswa'): ?>
                                        <form action="<?php echo e(route('user.datacomment.store', $forum->id)); ?>" method="POST"
                                            class="d-flex search-form w-100">
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="forum_id" value="<?php echo e($forum->id); ?>">
                                <input type="text" class="form-control <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> flex-grow-1"
                                    name="body" id="inputText" placeholder="Tulis Komentar" value="<?php echo e(old('body')); ?>">
                                <button type="submit" class="btn btn-primary ms-2">Kirim</button>
                                </form>
                            </div>
                        </div>
                    </div><!-- End Card with header and footer -->

                    <div class="comments-container" style="padding-left: 50px;">
                        <!-- Comments -->
                        <?php $__currentLoopData = $forum->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mb-3">
                                <div class="card-header">
                                    <div class="d-flex align-items-start">
                                        <?php if(($comment->admin && $comment->admin->foto) || ($comment->user && $comment->user->foto)): ?>
                                            <img src="<?php echo e($comment->admin && $comment->admin->foto ? asset('storage/foto/' . $comment->admin->foto) : asset('storage/foto/' . $comment->user->foto)); ?>"
                                                alt="Profile" class="rounded-circle"
                                                style="width: 45px; height: 45px; object-fit: cover; border-radius: 50%; margin-right: 10px;">
                                        <?php endif; ?>
                                        <div class="d-flex flex-column">
                                            re: <?php echo e($forum->judul); ?>

                                            <span style="font-size: 0.8em; color: gray;">
                                                by
                                                <b>
                                                    <?php if($comment->admin): ?>
                                                        <?php echo e($comment->admin->nama); ?> (<?php echo e($comment->admin->level); ?>)
                                                    <?php elseif($comment->user): ?>
                                                        <?php echo e($comment->user->nama); ?> (<?php echo e($comment->user->level); ?>)
                                                    <?php else: ?>
                                                        Admin dan User tidak tersedia
                                                    <?php endif; ?>
                                                </b>
                                                <?php echo e($comment->created_at->translatedFormat('l, j F Y, H:i A')); ?>

                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="content-justify mt-4" style="text-align: justify;">
                                        <?php echo e($comment->body); ?>

                                    </div>
                                </div>
                            </div><!-- End Card with header and footer -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </section>

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/forum/modal/detail.blade.php ENDPATH**/ ?>