<!-- Modal Edit Siswa-->
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="detailModal<?php echo e($item->id); ?>" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Data Siswa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="formEditSiswa<?php echo e($item->id); ?>" class="row g-3"
                        action="<?php echo e(route('datasiswa.update', $item->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input class="form-control <?php $__errorArgs = ['namaupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                    id="floatingNama" name="namaupdate" value="<?php echo e($item->nama); ?>" placeholder="Nama"
                                    required>
                                <label for="floatingNama">Nama</label>
                                <?php $__errorArgs = ['namaupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input class="form-control <?php $__errorArgs = ['nisupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                    id="floatingNis" name="nisupdate" value="<?php echo e($item->nis); ?>" placeholder="NIS"
                                    required>
                                <label for="floatingNis">NIS</label>
                                <?php $__errorArgs = ['nisupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <select class="form-select <?php $__errorArgs = ['levelupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="floatingSelect" aria-label="Level" name="levelupdate" placeholder="Level"
                                    required>
                                    <option value="siswa" <?php echo e($item->level == 'siswa' ? 'selected' : ''); ?> selected>
                                        Siswa</option>

                                </select>
                                <label for="floatingSelect">Level</label>
                                <?php $__errorArgs = ['levelupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-floating">
                                <select class="form-select" id="floatingSelectJurusan" aria-label="Jurusan"
                                    name="jurusan_idupdate" required>
                                    <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($jurusan->id); ?>"
                                            <?php echo e($item->jurusan_id == $jurusan->id ? 'selected' : ''); ?>>
                                            <?php echo e($jurusan->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="floatingSelectJurusan">Jurusan</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-floating">
                                <select class="form-select" id="floatingSelectKelas" aria-label="Kelas"
                                    name="kelasupdate" required>
                                    <option value="10" <?php echo e($item->kelas == '10' ? 'selected' : ''); ?>>10
                                    </option>
                                    <option value="11" <?php echo e($item->kelas == '11' ? 'selected' : ''); ?>>11
                                    </option>
                                    <option value="12" <?php echo e($item->kelas == '12' ? 'selected' : ''); ?>>12
                                    </option>
                                </select>
                                <label for="floatingSelectKelas">Kelas</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-floating">
                                <select class="form-select" id="floatingSelectSubkelas" aria-label="Subkelas"
                                    name="subkelasupdate" required>
                                    <option value="A" <?php echo e($item->subkelas == 'A' ? 'selected' : ''); ?>>A
                                    </option>
                                    <option value="B" <?php echo e($item->subkelas == 'B' ? 'selected' : ''); ?>>B
                                    </option>
                                    <option value="C" <?php echo e($item->subkelas == 'C' ? 'selected' : ''); ?>>C
                                    </option>
                                </select>
                                <label for="floatingSelectSubkelas">Subkelas</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-floating">
                                <select class="form-select" id="floatingSelectJenisKelamin" aria-label="Jenis Kelamin"
                                    name="jenis_kelaminupdate" required>
                                    <option value="L" <?php echo e($item->jenis_kelamin == 'L' ? 'selected' : ''); ?>>
                                        L
                                    </option>
                                    <option value="P" <?php echo e($item->jenis_kelamin == 'P' ? 'selected' : ''); ?>>
                                        P
                                    </option>
                                </select>
                                <label for="floatingSelectJenisKelamin">Jenis Kelamin</label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-floating">
                                <input class="form-control <?php $__errorArgs = ['tempat_lahirupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="text" id="floatingTempatLahir" name="tempat_lahirupdate"
                                    value="<?php echo e($item->tempat_lahir); ?>" placeholder="Tempat Lahir" required>
                                <label for="floatingTempatLahir">Tempat Lahir</label>
                                <?php $__errorArgs = ['tempat_lahirupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-floating">
                                <input class="form-control <?php $__errorArgs = ['tanggal_lahirupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="date" id="floatingTanggalLahir" name="tanggal_lahirupdate"
                                    value="<?php echo e($item->tanggal_lahir); ?>" placeholder="Tanggal Lahir" required>
                                <label for="floatingTanggalLahir">Tanggal Lahir</label>
                                <?php $__errorArgs = ['tanggal_lahirupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <textarea class="form-control <?php $__errorArgs = ['alamatupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingAlamat" name="alamatupdate"
                                    placeholder="Alamat" required><?php echo e($item->alamat); ?></textarea>
                                <label for="floatingAlamat">Alamat</label>
                                <?php $__errorArgs = ['alamatupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input class="form-control <?php $__errorArgs = ['nohpupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                    id="floatingNoHP" name="nohpupdate" value="<?php echo e($item->nohp); ?>"
                                    placeholder="No HP" required>
                                <label for="floatingNoHP">No HP</label>
                                <?php $__errorArgs = ['nohpupdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- End Modal Edit Siswa-->
<?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/siswa/modal/edit.blade.php ENDPATH**/ ?>