<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">

        <div class="pagetitle">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <h1>Data Siswa</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Data Siswa</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="card-title">Table Data Siswa</h5>
                                <!-- Form Pencarian -->
                                <form method="GET" action="<?php echo e(url('/admin/datasiswa')); ?>" class="d-flex search-form">
                                    <input style="margin-right: 10px;" type="text" name="search" class="form-control"
                                        placeholder="Cari data nama siswa..." value="<?php echo e(request('search')); ?>">

                                    <!-- Dropdown untuk memilih kelas -->
                                    <select name="kelas" class="form-control" style="margin-right: 10px;">
                                        <option value="">Semua Kelas</option>
                                        <?php $__currentLoopData = $kelasOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kelas); ?>" <?php echo e(request('kelas') == $kelas ? 'selected' : ''); ?>><?php echo e($kelas); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <!-- Dropdown untuk memilih jurusan -->
                                    <select name="jurusan" class="form-control" style="margin-right: 10px;">
                                        <option value="">Semua Jurusan</option>
                                        <?php $__currentLoopData = $jurusanOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($jurusan->id); ?>" <?php echo e(request('jurusan') == $jurusan->id ? 'selected' : ''); ?>>
                                                <?php echo e($jurusan->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <button type="submit" class="btn btn-primary">Cari</button>
                                </form>
                                <!-- End Form Pencarian -->
                            </div>

                            <!-- Button Modal Tambah Siswa-->
                            <button type="button" class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#tambahModal">
                                <i class="bi bi-plus me-1"></i> Tambah Data
                            </button>
                            <!-- End button Modal Tambah Siswa -->

                            <!-- Table with hoverable rows -->
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th style="width: 1%" scope="col">No</th>
                                        <th style="width: 9%" scope="col">NIS</th>
                                        <th style="width: 15%" scope="col">Nama</th>
                                        <th style="width: 15%" scope="col">Kelas</th>
                                        <th style="width: 1%"scope="col">Jenis Kelamin</th>
                                        <th style="width: 9%"scope="col">Tempat Lahir</th>
                                        <th style="width: 10%"scope="col">Tanggal Lahir</th>
                                        <th style="width: 10%"scope="col">Alamat</th>
                                        <th style="width: 10%"scope="col">No HP</th>
                                        <th style="width: 15%" scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row">
                                                <?php echo e(($users->currentPage() - 1) * $users->perPage() + $loop->iteration); ?>

                                            </th>
                                            <td><?php echo e($item->nis); ?></td>
                                            <td><?php echo e($item->nama); ?></td>
                                            <td><?php echo e($item->kelas); ?> <?php echo e($item->nama_jurusan); ?> <?php echo e($item->subkelas); ?></td>
                                            <td><?php echo e($item->jenis_kelamin); ?></td>
                                            <td><?php echo e($item->tempat_lahir); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_lahir)->format('d/m/Y')); ?></td>
                                            <td><?php echo e($item->alamat); ?></td>
                                            <td><?php echo e($item->nohp); ?></td>
                                            <td>
                                                <!-- Button Chat-->
                                                <button type="button" class="btn btn-success"
                                                    onclick="window.location.href='<?php echo e(route('admin.chat.detail', $item->id)); ?>'">
                                                    <i class="bi bi-chat-dots"></i>
                                                </button>
                                                <!-- End Chat-->

                                                <!-- Button Modal Edit Siswa-->
                                                <button type="button" class="btn btn-info" data-bs-toggle="modal"
                                                    data-bs-target="#detailModal<?php echo e($item->id); ?>">
                                                    <i class="bi bi-info-circle"></i>
                                                </button>
                                                <!-- End Button Modal Edit Siswa-->

                                                <!-- Button Modal Hapus Siswa-->
                                                <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                                    data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                                <!-- End Button Modal Hapus Siswa-->

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- End Table with stripped rows -->

                        </div>
                    </div>
                </div>
            </div>

            <!-- Paginate -->
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <!-- Previous Page Link -->
                    <?php if($users->onFirstPage()): ?>
                        <li class="page-item disabled"><span class="page-link">Previous</span></li>
                    <?php else: ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($users->previousPageUrl()); ?>">Previous</a>
                        </li>
                    <?php endif; ?>

                    <!-- Pagination Elements -->
                    <?php for($i = 1; $i <= $users->lastPage(); $i++): ?>
                        <li class="page-item <?php echo e($i == $users->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($users->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>

                    <!-- Next Page Link -->
                    <?php if($users->hasMorePages()): ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($users->nextPageUrl()); ?>">Next</a></li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link">Next</span></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <!-- End Paginate -->
        </section>

        <?php echo $__env->make('siswa.modal.tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('siswa.modal.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('siswa.modal.hapus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </main><!-- End #main -->

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // AJAX untuk form tambah siswa
            document.getElementById('formTambahSiswa').addEventListener('submit', function(e) {
                e.preventDefault();
                var form = this;

                fetch(form.action, {
                        method: form.method,
                        body: new FormData(form),
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.errors) {
                            // Tampilkan pesan kesalahan
                            Object.keys(data.errors).forEach(function(key) {
                                var input = document.querySelector(`[name="${key}"]`);
                                input.classList.add('is-invalid');
                                var feedback = input.nextElementSibling;
                                feedback.textContent = data.errors[key][0];
                                feedback.style.display = 'block';
                            });
                        } else {
                            // Sukses, redirect ke halaman yang diinginkan
                            window.location.href = data.redirect;
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });;
            });

            // AJAX untuk form edit siswa
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                document.getElementById('formEditSiswa<?php echo e($item->id); ?>').addEventListener('submit', function(
                    e) {
                    e.preventDefault();
                    var form = this;

                    fetch(form.action, {
                            method: form.method,
                            body: new FormData(form),
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.errors) {
                                // Tampilkan pesan kesalahan
                                Object.keys(data.errors).forEach(function(key) {
                                    var input = document.querySelector(`[name="${key}"]`);
                                    input.classList.add('is-invalid');
                                    var feedback = input.nextElementSibling;
                                    feedback.textContent = data.errors[key][0];
                                    feedback.style.display = 'block';
                                });
                            } else {
                                // Sukses, redirect ke halaman yang diinginkan
                                window.location.href = data.redirect;
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                        });
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Ambil pesan sukses dari sessionStorage jika ada
            var successMessage = sessionStorage.getItem('successMessage');
            if (successMessage) {
                // Tampilkan pesan sukses
                var alertDiv = document.createElement('div');
                alertDiv.classList.add('alert', 'alert-primary', 'alert-dismissible', 'fade', 'show');
                alertDiv.setAttribute('role', 'alert');
                alertDiv.innerHTML = successMessage +
                    '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                document.body.insertBefore(alertDiv, document.body.firstChild);
                sessionStorage.removeItem('successMessage');
            }
        });
    </script>

    <!-- Tambahkan JavaScript untuk menghapus parameter pencarian saat halaman di-refresh -->
    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('search');
            url.searchParams.delete('kelas');
            url.searchParams.delete('jurusan');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BreezeChatFix - Copy (2) - Copy\resources\views/siswa/data-siswa.blade.php ENDPATH**/ ?>