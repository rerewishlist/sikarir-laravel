<?php $__env->startSection('title', 'Materi Page'); ?>
<?php $__env->startSection('menuMateri', 'active'); ?>
<?php $__env->startSection('content-guest'); ?>

    <main class="main">

        <!-- Page Title -->
        <div class="page-title" data-aos="fade">
            <div class="container d-lg-flex justify-content-between align-items-center">
                <h1 class="mb-2 mb-lg-0">Materi Terbaru</h1>
                <nav class="breadcrumbs">
                    <ol>
                        <li><a href="<?php echo e(Route('dashboard')); ?>">Home</a></li>
                        <li class="current">Materi</li>
                    </ol>
                </nav>
            </div>
        </div><!-- End Page Title -->

        <!-- Service Details Section -->
        <section id="service-details" class="service-details section">
            <div class="container">
                <div class="row gy-5">
                    <?php if($materis->count() > 0): ?>
                        <div class="col-lg-3" data-aos="fade-up" data-aos-delay="100">
                            <div class="service-box">
                                <div class="services-list">
                                    <form action="">
                                        <input type="text" name="search_materi" class="form-control mb-3" placeholder="Cari judul materi..."
                                            value="<?php echo e(request('search_materi')); ?>">
                                        <?php
                                            $uniqueDates = collect($dates)
                                                ->map(function ($date) {
                                                    return \Carbon\Carbon::parse($date)->format('Y-m');
                                                })
                                                ->unique();
                                        ?>

                                        <select name="filter_tanggal" class="form-control" style="margin-right: 10px;">
                                            <option value="">-- Pilih Bulan dan Tahun --</option>
                                            <?php $__currentLoopData = $uniqueDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($date); ?>" <?php echo e(request('filter_tanggal') == $date ? 'selected' : ''); ?>>
                                                    <?php echo e(\Carbon\Carbon::parse($date)->format('F Y')); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <button type="submit" class="btn btn-primary mt-3">Cari</button>
                                    </form>
                                </div>
                            </div><!-- End Services List -->
                        </div>

                        <div class="col-lg-9 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
                            <?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(Route('user.materi.detail', $item->id)); ?>">
                                    <div class="d-flex align-items-center mb-2">
                                        <div class="col-md-1">
                                            <div class="icon-circle">
                                                <i class="bi bi-blockquote-left"></i>
                                            </div>
                                        </div>
                                        <div class="d-flex flex-column">
                                            <span style="font-size: 0.8em; color: gray;">
                                                <b>
                                                    <?php echo e($item->admin->nama); ?>

                                                </b>
                                                , memposting materi baru pada <?php echo e($item->created_at->translatedFormat('j F Y, H:i A')); ?>

                                            </span>
                                            <h3>
                                                <?php echo e($item->judul); ?>

                                            </h3>
                                        </div>
                                    </div>
                                    <hr>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- Paginate -->
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <!-- Previous Page Link -->
                                    <?php if($materis->onFirstPage()): ?>
                                        <li class="page-item disabled"><span class="page-link">Previous</span></li>
                                    <?php else: ?>
                                        <li class="page-item"><a class="page-link" href="<?php echo e($materis->previousPageUrl()); ?>">Previous</a>
                                        </li>
                                    <?php endif; ?>

                                    <!-- Pagination Elements -->
                                    <?php for($i = 1; $i <= $materis->lastPage(); $i++): ?>
                                        <li class="page-item <?php echo e($i == $materis->currentPage() ? 'active' : ''); ?>">
                                            <a class="page-link" href="<?php echo e($materis->url($i)); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>

                                    <!-- Next Page Link -->
                                    <?php if($materis->hasMorePages()): ?>
                                        <li class="page-item"><a class="page-link" href="<?php echo e($materis->nextPageUrl()); ?>">Next</a></li>
                                    <?php else: ?>
                                        <li class="page-item disabled"><span class="page-link">Next</span></li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                            <!-- End Paginate -->

                        </div>
                    <?php else: ?>
                        <div class="col-lg-9 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
                            <div class="mb-5">
                                <h3>Belum ada materi</h3>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </section><!-- /Service Details Section -->
    </main>

    <script>
        window.addEventListener('load', function() {
            // Menghapus parameter pencarian dari URL saat halaman di-refresh
            var url = new URL(window.location.href);
            url.searchParams.delete('filter_tanggal');
            url.searchParams.delete('search_materi');
            window.history.replaceState({}, document.title, url.toString());
        });
    </script>
    <style>
        .icon-circle {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            /* Sesuaikan ukuran lebar */
            height: 50px;
            /* Sesuaikan ukuran tinggi */
            border-radius: 50%;
            background-color: #828282;
            /* Warna latar belakang abu-abu */
        }

        .icon-circle i {
            font-size: 24px;
            /* Sesuaikan ukuran ikon */
            color: #ffffff;
            /* Warna ikon menjadi putih */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/menu-materi.blade.php ENDPATH**/ ?>