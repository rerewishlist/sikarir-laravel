<!-- resources/views/layouts/sidebar.blade.php -->
<div x-data="{ open: false }">
    <!-- Sidebar Toggle Button -->
    <button @click="open = !open" class="bg-white border-b border-gray-100 text-gray-800 p-4 focus:outline-none">
        <svg x-show="!open" class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M4 6h16M4 12h16M4 18h16"></path>
        </svg>
        <svg x-show="open" x-cloak class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M6 18L18 6M6 6l12 12"></path>
        </svg>
    </button>

    <!-- Sidebar -->
    <aside x-show="open" @click.away="open = false" x-transition class="w-64 bg-white text-gray-800 min-h-screen">
        <div class="p-4">
            <h2 class="text-xl font-semibold">Sidebar</h2>
        </div>
        <nav class="mt-2">
            <div class="hidden space-x-8 sm:-my-px sm:ml-10 sm:flex">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link','data' => ['href' => route('dashboard'),'active' => request()->routeIs('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard'))]); ?>
                    <?php echo e(__('Dashboard')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
            <a href="<?php echo e(route('dashboard')); ?>" class="block py-2.5 px-4 hover:bg-gray-100">Dashboard</a>
            <a href="<?php echo e(url('/profile')); ?>" class="block py-2.5 px-4 hover:bg-gray-100">Profile</a>
            <a href="<?php echo e(url('/settings')); ?>" class="block py-2.5 px-4 hover:bg-gray-100">Settings</a>
            <a href="<?php echo e(url('/logout')); ?>" class="block py-2.5 px-4 hover:bg-gray-100">Logout</a>
        </nav>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\BreezeChatFix\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>