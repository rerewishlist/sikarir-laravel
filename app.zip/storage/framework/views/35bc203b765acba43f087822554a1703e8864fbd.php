<section class="section">
    <div class="row">
        <div class="col-lg-12">

            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title">Materi Bimbingan dan Konseling</h5>
                        <!-- Form Pencarian -->
                        <form method="GET" action="<?php echo e(url('/admin/datamateri')); ?>" class="d-flex search-form">
                            <input style="margin-right: 10px;" type="text" name="search_materi" class="form-control"
                                placeholder="Cari judul materi..." value="<?php echo e(request('search_materi')); ?>">

                            <?php
                                $uniqueDates = collect($dates)
                                    ->map(function ($date) {
                                        return \Carbon\Carbon::parse($date)->format('Y-m');
                                    })
                                    ->unique();
                            ?>

                            <select name="filter_tanggal" class="form-control" style="margin-right: 10px;">
                                <option value="">-- Pilih Bulan dan Tahun --</option>
                                <?php $__currentLoopData = $uniqueDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($date); ?>" <?php echo e(request('filter_tanggal') == $date ? 'selected' : ''); ?>>
                                        <?php echo e(\Carbon\Carbon::parse($date)->format('F Y')); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <button type="submit" class="btn btn-primary">Cari</button>
                        </form>
                        <!-- End Form Pencarian -->
                    </div>

                </div>
            </div>

            <?php if($materis->count() > 0): ?>
                <?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('user.materi.detail', $item->id)); ?>">
                        <div class="card">
                            <div class="card-body">
                                <div class="row g-0">
                                    <div class="col-md-1">
                                        <div class="icon-circle mt-3 mb-0">
                                            <i class="bi bi-blockquote-left"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-11">
                                        <p class="card-text mt-3 mb-0"><?php echo e($item->admin->nama); ?> memposting materi baru: <?php echo e($item->judul); ?></p>
                                        <p class="card-text mb-0"><?php echo e($item->created_at->translatedFormat('d F Y')); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <p class="card-text mt-4">Tidak ada materi</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>

    <!-- Paginate -->
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <!-- Previous Page Link -->
            <?php if($materis->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link">Previous</span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($materis->previousPageUrl()); ?>">Previous</a>
                </li>
            <?php endif; ?>

            <!-- Pagination Elements -->
            <?php for($i = 1; $i <= $materis->lastPage(); $i++): ?>
                <li class="page-item <?php echo e($i == $materis->currentPage() ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($materis->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>

            <!-- Next Page Link -->
            <?php if($materis->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($materis->nextPageUrl()); ?>">Next</a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">Next</span></li>
            <?php endif; ?>
        </ul>
    </nav>
    <!-- End Paginate -->
</section>
<style>
    .icon-circle {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        /* Sesuaikan ukuran lebar */
        height: 50px;
        /* Sesuaikan ukuran tinggi */
        border-radius: 50%;
        background-color: #828282;
        /* Warna latar belakang abu-abu */
    }

    .icon-circle i {
        font-size: 24px;
        /* Sesuaikan ukuran ikon */
        color: #ffffff;
        /* Warna ikon menjadi putih */
    }
</style>
<?php /**PATH C:\xampp\htdocs\Skripsi FIX\resources\views/materi/materi-siswa.blade.php ENDPATH**/ ?>