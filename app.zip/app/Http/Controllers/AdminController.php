<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\Informasi;

class AdminController extends Controller
{
    public function index(Request $request)
    {
        // Buat query untuk mengambil data admins
        $query = Admin::query();
        // Urutkan dan paginasi hasilnya
        $alladmins = $query->orderBy('id', 'asc')->paginate(10);

        // Ambil admin_id dari request
        $adminId = $request->get('admin_id');

        // Jika ada admin_id dalam request, filter berdasarkan admin_id
        if ($adminId) {
            $admins = Admin::where('id', $adminId)->get(); // Ambil admin yang dipilih
        } else {
            $admins = collect(); // Tidak ada admin yang ditampilkan jika tidak ada admin_id
        }

        // Mengambil notifikasi
        $userNotif = auth()->user();
        // Ambil notifikasi berita dan forum
        $beritaforummateriNotifications = $userNotif->notifications()
            ->whereIn('type', ['App\Notifications\NewBeritaNotification', 'App\Notifications\NewForumNotification', 'App\Notifications\NewMateriNotification'])
            ->latest()
            ->take(5)
            ->get();

        // Ambil notifikasi chat
        $chatNotifications = $userNotif->notifications()
            ->where('type', 'App\Notifications\NewChatNotification')
            ->latest()
            ->get()
            ->unique('data.from_id');

        $informasi = Informasi::first();
        // Kembalikan view dengan data yang diperlukan
        return view('chat.data-chat-siswa', [
            'currentUser' => auth()->user(),
            'informasi' => $informasi,
            'admins' => $admins,
            'alladmins' => $alladmins,
            'beritaforummateriNotifications' => $beritaforummateriNotifications,
            'chatNotifications' => $chatNotifications,
        ]);
    }
}
